# Example Camera HAL Implementation

A complete, educational Camera HAL (Hardware Abstraction Layer) implementation for Android Open Source Project (AOSP).

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Directory Structure](#directory-structure)
- [Key Components](#key-components)
- [Building](#building)
- [Testing](#testing)
- [Debugging](#debugging)
- [Interview Topics Covered](#interview-topics-covered)

## Overview

This project provides a fully documented Camera HAL 3.5 implementation that demonstrates:

- **ICameraProvider** - Entry point for camera subsystem
- **ICameraDevice** - Physical camera representation
- **ICameraDeviceSession** - Active camera operations
- **Camera Metadata** - Static characteristics and dynamic settings
- **3A Algorithms** - Auto Exposure, Auto Focus, Auto White Balance
- **Stream Configuration** - Multiple output streams (preview, video, still)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Camera Application                          │
└────────────────────────────┬────────────────────────────────────┘
                             │ Camera2 API
┌────────────────────────────▼────────────────────────────────────┐
│                      Camera Framework                            │
│                (CameraManager, CameraDevice)                     │
└────────────────────────────┬────────────────────────────────────┘
                             │ HIDL IPC (Binder)
┌────────────────────────────▼────────────────────────────────────┐
│                   ExampleCameraProvider                          │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │  Camera 0 (Back)                  Camera 1 (Front)         ││
│  │  ┌──────────────────┐             ┌──────────────────┐     ││
│  │  │ ExampleCamera    │             │ ExampleCamera    │     ││
│  │  │    Device        │             │    Device        │     ││
│  │  └────────┬─────────┘             └────────┬─────────┘     ││
│  │           │                                │                 ││
│  │  ┌────────▼─────────┐             ┌────────▼─────────┐     ││
│  │  │ ExampleCamera    │             │ ExampleCamera    │     ││
│  │  │ DeviceSession    │             │ DeviceSession    │     ││
│  │  └──────────────────┘             └──────────────────┘     ││
│  └─────────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
vendor/meta/hardware/camera/
├── Android.bp                     # Build configuration
├── README.md                      # This file
├── service.cpp                    # Service entry point
│
├── common/                        # Shared utilities
│   ├── CameraMetadata.h          # Metadata helper classes
│   └── CameraMetadata.cpp
│
├── provider/2.7/                  # Camera Provider (HAL entry point)
│   ├── ExampleCameraProvider.h
│   └── ExampleCameraProvider.cpp
│
├── device/3.5/                    # Camera Device & Session
│   ├── ExampleCameraDevice.h
│   ├── ExampleCameraDevice.cpp
│   ├── ExampleCameraDeviceSession.h
│   └── ExampleCameraDeviceSession.cpp
│
├── etc/                           # Configuration files
│   ├── android.hardware.camera.provider@2.7-service.meta.rc
│   ├── android.hardware.camera.provider@2.7-service.meta.xml
│   └── camera_config.xml
│
├── sepolicy/                      # SELinux policies
│   ├── example_camera_hal.te
│   └── file_contexts
│
└── tests/                         # Unit tests (placeholder)
    ├── CameraProviderTest.cpp
    ├── CameraDeviceTest.cpp
    └── CameraSessionTest.cpp
```

## Key Components

### 1. Camera Provider (`ExampleCameraProvider`)

The entry point for the camera subsystem.

**Responsibilities:**
- Enumerate available cameras
- Create camera device instances
- Handle device state changes
- Manage vendor tags

**Key Methods:**
```cpp
getCameraIdList()              // List available cameras
getCameraDeviceInterface_V3_x() // Create camera device
setCallback()                   // Register status callbacks
```

### 2. Camera Device (`ExampleCameraDevice`)

Represents a physical camera.

**Responsibilities:**
- Provide static characteristics (capabilities)
- Create camera sessions
- Control torch mode
- Validate stream configurations

**Key Methods:**
```cpp
getCameraCharacteristics()  // Get static metadata
open()                       // Create session
setTorchMode()              // Control flash
isStreamCombinationSupported()
```

### 3. Camera Device Session (`ExampleCameraDeviceSession`)

Handles active camera operations.

**Responsibilities:**
- Configure output streams
- Process capture requests
- Run 3A algorithms
- Deliver capture results

**Key Methods:**
```cpp
configureStreams_3_5()           // Configure streams
processCaptureRequest_3_4()      // Submit captures
constructDefaultRequestSettings() // Get defaults
flush()                          // Cancel pending
close()                          // Close session
```

### 4. Camera Metadata Helpers

Utilities for building and parsing camera metadata.

**Classes:**
- `CameraMetadataHelper` - Low-level metadata operations
- `StaticMetadataBuilder` - Build camera characteristics
- `RequestMetadataBuilder` - Build capture settings

## Building

### Prerequisites

- AOSP source tree (with HIDL interfaces built)
- Android build environment set up

> **Note:** This example references HIDL-generated headers (e.g., `android/hardware/camera/device/3.5/types.h`) that are created during the AOSP build process. IDE errors about missing headers are expected until you run the full build.

### Build Commands

```bash
# Source build environment
source build/envsetup.sh
lunch <target>

# Build camera HAL
m android.hardware.camera.provider@2.7-service.meta

# Build with dependencies
m libexample_camera_metadata
m libexample_camera_device
m libexample_camera_provider

# Build tests
m example_camera_hal_test
```

### Push to Device

```bash
# Remount system for writing
adb root
adb remount

# Push HAL binary
adb push out/target/product/<device>/vendor/bin/hw/android.hardware.camera.provider@2.7-service.meta /vendor/bin/hw/

# Push manifest
adb push out/target/product/<device>/vendor/etc/vintf/manifest/android.hardware.camera.provider@2.7-service.meta.xml /vendor/etc/vintf/manifest/

# Restart camera service
adb shell stop cameraserver
adb shell start cameraserver
```

## Testing

### Run Unit Tests

```bash
atest example_camera_hal_test
```

### Manual Testing

```bash
# Check camera service
adb shell dumpsys media.camera

# List cameras
adb shell cmd camera list

# Check HAL registration
adb shell lshal | grep camera

# View camera logs
adb logcat -s ExampleCameraHAL ExampleCameraProvider ExampleCameraDevice ExampleCameraSession
```

## Debugging

### Enable Verbose Logging

```bash
# Enable debug logging
adb shell setprop vendor.camera.debug 1

# View logs
adb logcat -s ExampleCameraHAL:V
```

### Common Debug Commands

```bash
# Dump camera state
adb shell dumpsys media.camera

# Check VINTF compatibility
adb shell vintf

# SELinux denials
adb logcat | grep -i avc | grep camera

# Service status
adb shell service check media.camera
```

### GDB Debugging

```bash
# Start gdbserver on device
adb shell gdbserver :5039 --attach $(pidof android.hardware.camera.provider@2.7-service.meta)

# Forward port
adb forward tcp:5039 tcp:5039

# Connect GDB
gdb out/target/product/<device>/symbols/vendor/bin/hw/android.hardware.camera.provider@2.7-service.meta
(gdb) target remote localhost:5039
```

## Interview Topics Covered

This implementation covers the following key AOSP interview topics:

### 1. Camera HAL Architecture
- HAL versioning (HAL1 vs HAL3)
- HIDL interface definitions
- Service registration and discovery

### 2. Binder IPC
- HIDL transport mechanism
- Callback interfaces
- Thread pool management

### 3. Camera Metadata
- Static characteristics
- Request settings
- Capture results

### 4. 3A Algorithms
- Auto Exposure (AE)
- Auto Focus (AF)
- Auto White Balance (AWB)

### 5. Stream Management
- Multi-stream configuration
- Buffer management (Gralloc)
- Stream types (preview, video, JPEG)

### 6. Build System
- Android.bp (Soong/Blueprint)
- HIDL interface compilation
- Vendor partition integration

### 7. SELinux
- HAL domain policies
- Binder permissions
- Device access control

### 8. Init System
- Service configuration (.rc files)
- Property triggers
- Service dependencies

### 9. VINTF
- Manifest fragments
- HAL compatibility
- Version negotiation

## License

```
Copyright (C) 2024 Meta Platforms, Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0
```

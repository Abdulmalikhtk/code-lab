/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

#define LOG_TAG "CameraMetadataHelper"

#include "CameraMetadata.h"

#include <log/log.h>
#include <system/camera_metadata.h>

namespace android {
namespace hardware {
namespace camera {
namespace common {

// ============================================================================
// CameraMetadataHelper Implementation
// ============================================================================

CameraMetadataHelper::CameraMetadataHelper() : mMetadata(nullptr) {}

CameraMetadataHelper::~CameraMetadataHelper() {
    if (mMetadata) {
        free_camera_metadata(mMetadata);
        mMetadata = nullptr;
    }
}

bool CameraMetadataHelper::initialize(size_t entryCapacity, size_t dataCapacity) {
    if (mMetadata) {
        free_camera_metadata(mMetadata);
    }
    mMetadata = allocate_camera_metadata(entryCapacity, dataCapacity);
    return mMetadata != nullptr;
}

bool CameraMetadataHelper::initialize(const camera_metadata_t* metadata) {
    if (mMetadata) {
        free_camera_metadata(mMetadata);
    }
    if (!metadata) {
        mMetadata = nullptr;
        return false;
    }
    mMetadata = clone_camera_metadata(metadata);
    return mMetadata != nullptr;
}

CameraMetadata CameraMetadataHelper::toHidl() const {
    CameraMetadata hidlMetadata;
    if (mMetadata) {
        size_t size = get_camera_metadata_size(mMetadata);
        hidlMetadata.resize(size);
        memcpy(hidlMetadata.data(), mMetadata, size);
    }
    return hidlMetadata;
}

CameraMetadataHelper CameraMetadataHelper::fromHidl(const CameraMetadata& hidlMetadata) {
    CameraMetadataHelper helper;
    if (!hidlMetadata.size()) {
        return helper;
    }
    const camera_metadata_t* metadata =
        reinterpret_cast<const camera_metadata_t*>(hidlMetadata.data());
    helper.initialize(metadata);
    return helper;
}

// ============================================================================
// StaticMetadataBuilder Implementation
// ============================================================================

StaticMetadataBuilder::StaticMetadataBuilder() {
    mMetadata.initialize(256, 2048);
}

StaticMetadataBuilder& StaticMetadataBuilder::setSensorSize(int32_t width, int32_t height) {
    int32_t size[] = {width, height};
    mMetadata.update(ANDROID_SENSOR_INFO_PIXEL_ARRAY_SIZE, size, 2);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setPixelArraySize(int32_t width, int32_t height) {
    int32_t size[] = {width, height};
    mMetadata.update(ANDROID_SENSOR_INFO_PIXEL_ARRAY_SIZE, size, 2);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setActiveArraySize(
    int32_t left, int32_t top, int32_t right, int32_t bottom) {
    int32_t rect[] = {left, top, right, bottom};
    mMetadata.update(ANDROID_SENSOR_INFO_ACTIVE_ARRAY_SIZE, rect, 4);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setPhysicalSize(float width, float height) {
    float size[] = {width, height};
    mMetadata.update(ANDROID_SENSOR_INFO_PHYSICAL_SIZE, size, 2);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setFocalLengths(
    const std::vector<float>& focalLengths) {
    mMetadata.update(ANDROID_LENS_INFO_AVAILABLE_FOCAL_LENGTHS, focalLengths);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setApertures(
    const std::vector<float>& apertures) {
    mMetadata.update(ANDROID_LENS_INFO_AVAILABLE_APERTURES, apertures);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setMinimumFocusDistance(float distance) {
    mMetadata.update(ANDROID_LENS_INFO_MINIMUM_FOCUS_DISTANCE, distance);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setFacing(int32_t facing) {
    uint8_t f = static_cast<uint8_t>(facing);
    mMetadata.update(ANDROID_LENS_FACING, f);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setOrientation(int32_t orientation) {
    mMetadata.update(ANDROID_SENSOR_ORIENTATION, orientation);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::addStreamConfiguration(
    int32_t format, int32_t width, int32_t height, int64_t duration) {
    mStreamConfigs.push_back(format);
    mStreamConfigs.push_back(width);
    mStreamConfigs.push_back(height);
    mStreamConfigs.push_back(0);  // OUTPUT stream type

    mStreamDurations.push_back(format);
    mStreamDurations.push_back(width);
    mStreamDurations.push_back(height);
    mStreamDurations.push_back(duration);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setHardwareLevel(int32_t level) {
    uint8_t l = static_cast<uint8_t>(level);
    mMetadata.update(ANDROID_INFO_SUPPORTED_HARDWARE_LEVEL, l);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setAvailableCapabilities(
    const std::vector<int32_t>& capabilities) {
    std::vector<uint8_t> caps;
    for (int32_t c : capabilities) {
        caps.push_back(static_cast<uint8_t>(c));
    }
    mMetadata.update(ANDROID_REQUEST_AVAILABLE_CAPABILITIES, caps);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setAEModes(const std::vector<int32_t>& modes) {
    std::vector<uint8_t> m;
    for (int32_t mode : modes) {
        m.push_back(static_cast<uint8_t>(mode));
    }
    mMetadata.update(ANDROID_CONTROL_AE_AVAILABLE_MODES, m);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setAFModes(const std::vector<int32_t>& modes) {
    std::vector<uint8_t> m;
    for (int32_t mode : modes) {
        m.push_back(static_cast<uint8_t>(mode));
    }
    mMetadata.update(ANDROID_CONTROL_AF_AVAILABLE_MODES, m);
    return *this;
}

StaticMetadataBuilder& StaticMetadataBuilder::setAWBModes(const std::vector<int32_t>& modes) {
    std::vector<uint8_t> m;
    for (int32_t mode : modes) {
        m.push_back(static_cast<uint8_t>(mode));
    }
    mMetadata.update(ANDROID_CONTROL_AWB_AVAILABLE_MODES, m);
    return *this;
}

CameraMetadataHelper StaticMetadataBuilder::build() {
    // Add stream configurations
    if (!mStreamConfigs.empty()) {
        mMetadata.update(ANDROID_SCALER_AVAILABLE_STREAM_CONFIGURATIONS, mStreamConfigs);
    }
    if (!mStreamDurations.empty()) {
        mMetadata.update(ANDROID_SCALER_AVAILABLE_MIN_FRAME_DURATIONS, mStreamDurations);
        mMetadata.update(ANDROID_SCALER_AVAILABLE_STALL_DURATIONS, mStreamDurations);
    }

    return std::move(mMetadata);
}

// ============================================================================
// RequestMetadataBuilder Implementation
// ============================================================================

RequestMetadataBuilder::RequestMetadataBuilder() {
    mMetadata.initialize(64, 512);
}

RequestMetadataBuilder& RequestMetadataBuilder::setAEMode(int32_t mode) {
    uint8_t m = static_cast<uint8_t>(mode);
    mMetadata.update(ANDROID_CONTROL_AE_MODE, m);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setAFMode(int32_t mode) {
    uint8_t m = static_cast<uint8_t>(mode);
    mMetadata.update(ANDROID_CONTROL_AF_MODE, m);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setAWBMode(int32_t mode) {
    uint8_t m = static_cast<uint8_t>(mode);
    mMetadata.update(ANDROID_CONTROL_AWB_MODE, m);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setExposureTime(int64_t ns) {
    mMetadata.update(ANDROID_SENSOR_EXPOSURE_TIME, ns);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setSensitivity(int32_t iso) {
    mMetadata.update(ANDROID_SENSOR_SENSITIVITY, iso);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setExposureCompensation(int32_t ev) {
    mMetadata.update(ANDROID_CONTROL_AE_EXPOSURE_COMPENSATION, ev);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setFocusDistance(float distance) {
    mMetadata.update(ANDROID_LENS_FOCUS_DISTANCE, distance);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setAFRegions(const std::vector<int32_t>& regions) {
    mMetadata.update(ANDROID_CONTROL_AF_REGIONS, regions);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setJpegQuality(uint8_t quality) {
    mMetadata.update(ANDROID_JPEG_QUALITY, quality);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setJpegOrientation(int32_t orientation) {
    mMetadata.update(ANDROID_JPEG_ORIENTATION, orientation);
    return *this;
}

RequestMetadataBuilder& RequestMetadataBuilder::setFlashMode(int32_t mode) {
    uint8_t m = static_cast<uint8_t>(mode);
    mMetadata.update(ANDROID_FLASH_MODE, m);
    return *this;
}

CameraMetadataHelper RequestMetadataBuilder::build() {
    return std::move(mMetadata);
}

}  // namespace common
}  // namespace camera
}  // namespace hardware
}  // namespace android

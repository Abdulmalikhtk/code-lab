/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

#pragma once

#include <android/hardware/camera/device/3.5/types.h>
#include <system/camera_metadata.h>

#include <map>
#include <mutex>
#include <string>
#include <vector>

namespace android {
namespace hardware {
namespace camera {
namespace common {

using ::android::hardware::camera::device::V3_5::CameraMetadata;

/**
 * CameraMetadataHelper - Utility class for managing camera metadata
 *
 * This class provides helper functions for creating and manipulating
 * camera metadata structures used throughout the Camera HAL.
 */
class CameraMetadataHelper {
public:
    CameraMetadataHelper();
    ~CameraMetadataHelper();

    // Initialize with empty metadata
    bool initialize(size_t entryCapacity = 64, size_t dataCapacity = 512);

    // Initialize from existing metadata
    bool initialize(const camera_metadata_t* metadata);

    // Get raw metadata pointer
    camera_metadata_t* getMetadata() const { return mMetadata; }

    // Update metadata entries
    template <typename T>
    bool update(uint32_t tag, const T* data, size_t count) {
        if (!mMetadata) return false;
        return camera_metadata_update_entry(mMetadata, tag, data, count) == 0;
    }

    // Update single value
    template <typename T>
    bool update(uint32_t tag, const T& value) {
        return update(tag, &value, 1);
    }

    // Update vector
    template <typename T>
    bool update(uint32_t tag, const std::vector<T>& values) {
        return update(tag, values.data(), values.size());
    }

    // Get metadata entry
    template <typename T>
    bool get(uint32_t tag, T* value) const {
        if (!mMetadata || !value) return false;
        camera_metadata_ro_entry_t entry;
        if (find_camera_metadata_ro_entry(mMetadata, tag, &entry) != 0) {
            return false;
        }
        if (entry.count < 1) return false;
        *value = *reinterpret_cast<const T*>(entry.data.u8);
        return true;
    }

    // Convert to HIDL CameraMetadata type
    CameraMetadata toHidl() const;

    // Create from HIDL CameraMetadata
    static CameraMetadataHelper fromHidl(const CameraMetadata& hidlMetadata);

    // Lock for thread-safe access
    void lock() { mMutex.lock(); }
    void unlock() { mMutex.unlock(); }

private:
    camera_metadata_t* mMetadata;
    mutable std::mutex mMutex;
};

/**
 * StaticMetadataBuilder - Builder for camera static characteristics
 */
class StaticMetadataBuilder {
public:
    StaticMetadataBuilder();

    // Sensor information
    StaticMetadataBuilder& setSensorSize(int32_t width, int32_t height);
    StaticMetadataBuilder& setPixelArraySize(int32_t width, int32_t height);
    StaticMetadataBuilder& setActiveArraySize(int32_t left, int32_t top,
                                               int32_t right, int32_t bottom);
    StaticMetadataBuilder& setPhysicalSize(float width, float height);

    // Lens information
    StaticMetadataBuilder& setFocalLengths(const std::vector<float>& focalLengths);
    StaticMetadataBuilder& setApertures(const std::vector<float>& apertures);
    StaticMetadataBuilder& setMinimumFocusDistance(float distance);
    StaticMetadataBuilder& setFacing(int32_t facing);
    StaticMetadataBuilder& setOrientation(int32_t orientation);

    // Stream configuration
    StaticMetadataBuilder& addStreamConfiguration(int32_t format, int32_t width,
                                                   int32_t height, int64_t duration);

    // Capabilities
    StaticMetadataBuilder& setHardwareLevel(int32_t level);
    StaticMetadataBuilder& setAvailableCapabilities(const std::vector<int32_t>& capabilities);

    // 3A support
    StaticMetadataBuilder& setAEModes(const std::vector<int32_t>& modes);
    StaticMetadataBuilder& setAFModes(const std::vector<int32_t>& modes);
    StaticMetadataBuilder& setAWBModes(const std::vector<int32_t>& modes);

    // Build the metadata
    CameraMetadataHelper build();

private:
    CameraMetadataHelper mMetadata;
    std::vector<int32_t> mStreamConfigs;
    std::vector<int64_t> mStreamDurations;
};

/**
 * RequestMetadataBuilder - Builder for capture request settings
 */
class RequestMetadataBuilder {
public:
    RequestMetadataBuilder();

    // 3A control modes
    RequestMetadataBuilder& setAEMode(int32_t mode);
    RequestMetadataBuilder& setAFMode(int32_t mode);
    RequestMetadataBuilder& setAWBMode(int32_t mode);

    // Exposure control
    RequestMetadataBuilder& setExposureTime(int64_t ns);
    RequestMetadataBuilder& setSensitivity(int32_t iso);
    RequestMetadataBuilder& setExposureCompensation(int32_t ev);

    // Focus control
    RequestMetadataBuilder& setFocusDistance(float distance);
    RequestMetadataBuilder& setAFRegions(const std::vector<int32_t>& regions);

    // Image quality
    RequestMetadataBuilder& setJpegQuality(uint8_t quality);
    RequestMetadataBuilder& setJpegOrientation(int32_t orientation);

    // Flash control
    RequestMetadataBuilder& setFlashMode(int32_t mode);

    // Build the metadata
    CameraMetadataHelper build();

private:
    CameraMetadataHelper mMetadata;
};

}  // namespace common
}  // namespace camera
}  // namespace hardware
}  // namespace android

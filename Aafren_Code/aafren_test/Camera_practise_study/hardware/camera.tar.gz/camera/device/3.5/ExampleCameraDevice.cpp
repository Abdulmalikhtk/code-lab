/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

#define LOG_TAG "ExampleCameraDevice"

#include "ExampleCameraDevice.h"
#include "ExampleCameraDeviceSession.h"

#include <log/log.h>
#include <system/camera_metadata.h>

namespace android {
namespace hardware {
namespace camera {
namespace device {
namespace V3_5 {
namespace implementation {

using ::android::hardware::camera::device::V3_2::RequestTemplate;

// ============================================================================
// Constants
// ============================================================================

// Sensor specifications (example values for a typical smartphone camera)
static const int32_t kBackCameraSensorWidth = 4032;
static const int32_t kBackCameraSensorHeight = 3024;
static const int32_t kFrontCameraSensorWidth = 3264;
static const int32_t kFrontCameraSensorHeight = 2448;

// Physical sensor size in mm (used for FoV calculations)
static const float kBackCameraSensorPhysicalWidth = 5.64f;
static const float kBackCameraSensorPhysicalHeight = 4.23f;
static const float kFrontCameraSensorPhysicalWidth = 4.8f;
static const float kFrontCameraSensorPhysicalHeight = 3.6f;

// Supported resolutions for preview/video
static const struct Resolution {
    int32_t width;
    int32_t height;
} kSupportedResolutions[] = {
    {4032, 3024},  // Full sensor (back)
    {3840, 2160},  // 4K UHD
    {1920, 1080},  // 1080p
    {1280, 720},   // 720p
    {640, 480},    // VGA
    {320, 240},    // QVGA
};

// ============================================================================
// Constructor / Destructor
// ============================================================================

ExampleCameraDevice::ExampleCameraDevice(const std::string& cameraId)
    : mCameraId(cameraId),
      mIsOpen(false),
      mTorchEnabled(false),
      mCallback(nullptr) {

    ALOGI("ExampleCameraDevice created for camera %s", cameraId.c_str());

    // Initialize camera based on ID
    initializeCamera();
}

ExampleCameraDevice::~ExampleCameraDevice() {
    ALOGI("ExampleCameraDevice destroyed for camera %s", mCameraId.c_str());
}

// ============================================================================
// Initialization
// ============================================================================

bool ExampleCameraDevice::initializeCamera() {
    // Determine camera type based on ID
    // Camera 0 = Back camera, Camera 1 = Front camera
    int cameraNum = std::stoi(mCameraId);

    if (cameraNum == 0) {
        // Back camera configuration
        mFacing = CameraFacing::BACK;
        mSensorWidth = kBackCameraSensorWidth;
        mSensorHeight = kBackCameraSensorHeight;
        mHasFlash = true;
        mHardwareLevel = HardwareLevel::FULL;
        ALOGI("Configured as BACK camera: %dx%d, hasFlash=%d",
              mSensorWidth, mSensorHeight, mHasFlash);
    } else {
        // Front camera configuration
        mFacing = CameraFacing::FRONT;
        mSensorWidth = kFrontCameraSensorWidth;
        mSensorHeight = kFrontCameraSensorHeight;
        mHasFlash = false;
        mHardwareLevel = HardwareLevel::LIMITED;
        ALOGI("Configured as FRONT camera: %dx%d, hasFlash=%d",
              mSensorWidth, mSensorHeight, mHasFlash);
    }

    // Build static characteristics
    buildStaticCharacteristics();

    return true;
}

void ExampleCameraDevice::buildStaticCharacteristics() {
    // Initialize metadata
    mCharacteristics.initialize(256, 4096);

    camera_metadata_t* meta = mCharacteristics.getMetadata();
    if (!meta) {
        ALOGE("Failed to initialize characteristics metadata");
        return;
    }

    // ========================================================================
    // Lens Information
    // ========================================================================

    // Lens facing direction
    uint8_t lensFacing = static_cast<uint8_t>(mFacing);
    add_camera_metadata_entry(meta, ANDROID_LENS_FACING, &lensFacing, 1);

    // Focal lengths (typical smartphone values)
    float focalLengths[] = {4.25f};  // 4.25mm typical for smartphone
    add_camera_metadata_entry(meta, ANDROID_LENS_INFO_AVAILABLE_FOCAL_LENGTHS,
                              focalLengths, 1);

    // Apertures
    float apertures[] = {1.8f, 2.2f};
    add_camera_metadata_entry(meta, ANDROID_LENS_INFO_AVAILABLE_APERTURES,
                              apertures, 2);

    // Minimum focus distance (0.1 = 10cm macro)
    float minFocusDist = 0.1f;
    add_camera_metadata_entry(meta, ANDROID_LENS_INFO_MINIMUM_FOCUS_DISTANCE,
                              &minFocusDist, 1);

    // ========================================================================
    // Sensor Information
    // ========================================================================

    // Sensor orientation (0, 90, 180, 270 degrees)
    int32_t sensorOrientation = (mFacing == CameraFacing::FRONT) ? 270 : 90;
    add_camera_metadata_entry(meta, ANDROID_SENSOR_ORIENTATION,
                              &sensorOrientation, 1);

    // Pixel array size
    int32_t pixelArraySize[] = {mSensorWidth, mSensorHeight};
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_PIXEL_ARRAY_SIZE,
                              pixelArraySize, 2);

    // Active array size
    int32_t activeArraySize[] = {0, 0, mSensorWidth, mSensorHeight};
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_ACTIVE_ARRAY_SIZE,
                              activeArraySize, 4);

    // Physical sensor size (mm)
    float physicalSize[2];
    if (mFacing == CameraFacing::BACK) {
        physicalSize[0] = kBackCameraSensorPhysicalWidth;
        physicalSize[1] = kBackCameraSensorPhysicalHeight;
    } else {
        physicalSize[0] = kFrontCameraSensorPhysicalWidth;
        physicalSize[1] = kFrontCameraSensorPhysicalHeight;
    }
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_PHYSICAL_SIZE,
                              physicalSize, 2);

    // Exposure time range (ns): 100us to 1s
    int64_t exposureTimeRange[] = {100000, 1000000000};
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_EXPOSURE_TIME_RANGE,
                              exposureTimeRange, 2);

    // ISO sensitivity range
    int32_t sensitivityRange[] = {50, 3200};
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_SENSITIVITY_RANGE,
                              sensitivityRange, 2);

    // Max analog sensitivity
    int32_t maxAnalogSensitivity = 1600;
    add_camera_metadata_entry(meta, ANDROID_SENSOR_MAX_ANALOG_SENSITIVITY,
                              &maxAnalogSensitivity, 1);

    // Timestamp source
    uint8_t timestampSource = ANDROID_SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME;
    add_camera_metadata_entry(meta, ANDROID_SENSOR_INFO_TIMESTAMP_SOURCE,
                              &timestampSource, 1);

    // ========================================================================
    // Flash Information
    // ========================================================================

    uint8_t flashAvailable = mHasFlash ? 1 : 0;
    add_camera_metadata_entry(meta, ANDROID_FLASH_INFO_AVAILABLE,
                              &flashAvailable, 1);

    // ========================================================================
    // Control Capabilities
    // ========================================================================

    // AE modes
    uint8_t aeModes[] = {
        ANDROID_CONTROL_AE_MODE_OFF,
        ANDROID_CONTROL_AE_MODE_ON,
        ANDROID_CONTROL_AE_MODE_ON_AUTO_FLASH,
        ANDROID_CONTROL_AE_MODE_ON_ALWAYS_FLASH
    };
    int aeModesCount = mHasFlash ? 4 : 2;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_AVAILABLE_MODES,
                              aeModes, aeModesCount);

    // AF modes
    uint8_t afModes[] = {
        ANDROID_CONTROL_AF_MODE_OFF,
        ANDROID_CONTROL_AF_MODE_AUTO,
        ANDROID_CONTROL_AF_MODE_MACRO,
        ANDROID_CONTROL_AF_MODE_CONTINUOUS_VIDEO,
        ANDROID_CONTROL_AF_MODE_CONTINUOUS_PICTURE
    };
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AF_AVAILABLE_MODES,
                              afModes, 5);

    // AWB modes
    uint8_t awbModes[] = {
        ANDROID_CONTROL_AWB_MODE_OFF,
        ANDROID_CONTROL_AWB_MODE_AUTO,
        ANDROID_CONTROL_AWB_MODE_INCANDESCENT,
        ANDROID_CONTROL_AWB_MODE_FLUORESCENT,
        ANDROID_CONTROL_AWB_MODE_DAYLIGHT,
        ANDROID_CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
    };
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AWB_AVAILABLE_MODES,
                              awbModes, 6);

    // Scene modes
    uint8_t sceneModes[] = {ANDROID_CONTROL_SCENE_MODE_DISABLED};
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AVAILABLE_SCENE_MODES,
                              sceneModes, 1);

    // Effect modes
    uint8_t effectModes[] = {ANDROID_CONTROL_EFFECT_MODE_OFF};
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AVAILABLE_EFFECTS,
                              effectModes, 1);

    // Control modes
    uint8_t controlModes[] = {
        ANDROID_CONTROL_MODE_OFF,
        ANDROID_CONTROL_MODE_AUTO,
        ANDROID_CONTROL_MODE_USE_SCENE_MODE
    };
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AVAILABLE_MODES,
                              controlModes, 3);

    // AE compensation range
    int32_t aeCompRange[] = {-4, 4};  // -4 to +4 EV
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_COMPENSATION_RANGE,
                              aeCompRange, 2);

    // AE compensation step (1/3 EV)
    camera_metadata_rational_t aeCompStep = {1, 3};
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_COMPENSATION_STEP,
                              &aeCompStep, 1);

    // ========================================================================
    // Stream Configuration
    // ========================================================================

    // Build stream configurations
    std::vector<int32_t> streamConfigs;
    std::vector<int64_t> minDurations;
    std::vector<int64_t> stallDurations;

    // Supported formats
    int32_t formats[] = {
        HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED,  // Preview/Video
        HAL_PIXEL_FORMAT_YCbCr_420_888,           // YUV processing
        HAL_PIXEL_FORMAT_BLOB                      // JPEG
    };

    int numResolutions = sizeof(kSupportedResolutions) / sizeof(kSupportedResolutions[0]);

    for (int32_t format : formats) {
        for (int i = 0; i < numResolutions; i++) {
            // Skip resolutions larger than sensor
            if (kSupportedResolutions[i].width > mSensorWidth ||
                kSupportedResolutions[i].height > mSensorHeight) {
                continue;
            }

            // Stream configuration: format, width, height, direction
            streamConfigs.push_back(format);
            streamConfigs.push_back(kSupportedResolutions[i].width);
            streamConfigs.push_back(kSupportedResolutions[i].height);
            streamConfigs.push_back(ANDROID_SCALER_AVAILABLE_STREAM_CONFIGURATIONS_OUTPUT);

            // Min frame duration (33ms for 30fps)
            int64_t duration = 33333333;  // ~30fps
            minDurations.push_back(format);
            minDurations.push_back(kSupportedResolutions[i].width);
            minDurations.push_back(kSupportedResolutions[i].height);
            minDurations.push_back(duration);

            // Stall duration (0 for non-JPEG, ~100ms for JPEG)
            int64_t stallDuration = (format == HAL_PIXEL_FORMAT_BLOB) ? 100000000 : 0;
            stallDurations.push_back(format);
            stallDurations.push_back(kSupportedResolutions[i].width);
            stallDurations.push_back(kSupportedResolutions[i].height);
            stallDurations.push_back(stallDuration);
        }
    }

    add_camera_metadata_entry(meta, ANDROID_SCALER_AVAILABLE_STREAM_CONFIGURATIONS,
                              streamConfigs.data(), streamConfigs.size());
    add_camera_metadata_entry(meta, ANDROID_SCALER_AVAILABLE_MIN_FRAME_DURATIONS,
                              minDurations.data(), minDurations.size());
    add_camera_metadata_entry(meta, ANDROID_SCALER_AVAILABLE_STALL_DURATIONS,
                              stallDurations.data(), stallDurations.size());

    // ========================================================================
    // Capabilities & Hardware Level
    // ========================================================================

    // Request capabilities
    uint8_t capabilities[] = {
        ANDROID_REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE,
        ANDROID_REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR,
        ANDROID_REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING,
        ANDROID_REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS
    };
    int capsCount = (mHardwareLevel == HardwareLevel::FULL) ? 4 : 1;
    add_camera_metadata_entry(meta, ANDROID_REQUEST_AVAILABLE_CAPABILITIES,
                              capabilities, capsCount);

    // Hardware level
    uint8_t hwLevel = static_cast<uint8_t>(mHardwareLevel);
    add_camera_metadata_entry(meta, ANDROID_INFO_SUPPORTED_HARDWARE_LEVEL,
                              &hwLevel, 1);

    // Max regions for 3A
    int32_t maxRegions[] = {1, 1, 1};  // AE, AWB, AF
    add_camera_metadata_entry(meta, ANDROID_CONTROL_MAX_REGIONS, maxRegions, 3);

    // Request keys (simplified list)
    int32_t requestKeys[] = {
        ANDROID_CONTROL_MODE,
        ANDROID_CONTROL_AE_MODE,
        ANDROID_CONTROL_AF_MODE,
        ANDROID_CONTROL_AWB_MODE,
        ANDROID_SENSOR_EXPOSURE_TIME,
        ANDROID_SENSOR_SENSITIVITY
    };
    add_camera_metadata_entry(meta, ANDROID_REQUEST_AVAILABLE_REQUEST_KEYS,
                              requestKeys, sizeof(requestKeys)/sizeof(int32_t));

    // Result keys (simplified list)
    int32_t resultKeys[] = {
        ANDROID_CONTROL_AE_STATE,
        ANDROID_CONTROL_AF_STATE,
        ANDROID_CONTROL_AWB_STATE,
        ANDROID_SENSOR_EXPOSURE_TIME,
        ANDROID_SENSOR_SENSITIVITY,
        ANDROID_SENSOR_TIMESTAMP
    };
    add_camera_metadata_entry(meta, ANDROID_REQUEST_AVAILABLE_RESULT_KEYS,
                              resultKeys, sizeof(resultKeys)/sizeof(int32_t));

    // Characteristics keys (simplified list)
    int32_t charKeys[] = {
        ANDROID_LENS_FACING,
        ANDROID_SENSOR_ORIENTATION,
        ANDROID_SENSOR_INFO_PIXEL_ARRAY_SIZE,
        ANDROID_FLASH_INFO_AVAILABLE,
        ANDROID_INFO_SUPPORTED_HARDWARE_LEVEL
    };
    add_camera_metadata_entry(meta, ANDROID_REQUEST_AVAILABLE_CHARACTERISTICS_KEYS,
                              charKeys, sizeof(charKeys)/sizeof(int32_t));

    ALOGI("Built static characteristics with %zu entries",
          get_camera_metadata_entry_count(meta));
}

// ============================================================================
// ICameraDevice Interface Implementation
// ============================================================================

Return<void> ExampleCameraDevice::getResourceCost(getResourceCost_cb _hidl_cb) {
    ALOGI("getResourceCost called for camera %s", mCameraId.c_str());

    ::android::hardware::camera::common::V1_0::CameraResourceCost resourceCost;

    // Resource cost: 100 = exclusive, 50 = can share with one other camera
    resourceCost.resourceCost = 50;

    // List of conflicting devices (none in this simple example)
    resourceCost.conflictingDevices.resize(0);

    _hidl_cb(Status::OK, resourceCost);
    return Void();
}

Return<void> ExampleCameraDevice::getCameraCharacteristics(
    getCameraCharacteristics_cb _hidl_cb) {

    ALOGI("getCameraCharacteristics called for camera %s", mCameraId.c_str());

    CameraMetadata hidlMetadata = mCharacteristics.toHidl();
    _hidl_cb(Status::OK, hidlMetadata);
    return Void();
}

Return<Status> ExampleCameraDevice::setTorchMode(TorchMode mode) {
    ALOGI("setTorchMode called: mode=%d for camera %s",
          static_cast<int>(mode), mCameraId.c_str());

    if (!mHasFlash) {
        ALOGE("Camera %s does not have flash", mCameraId.c_str());
        return Status::ILLEGAL_ARGUMENT;
    }

    if (mIsOpen) {
        ALOGE("Cannot set torch mode while camera is open");
        return Status::CAMERA_IN_USE;
    }

    // In a real implementation, this would control the hardware flash
    bool enable = (mode == TorchMode::ON);

    // Simulate hardware control
    ALOGI("Setting torch mode to %s", enable ? "ON" : "OFF");
    mTorchEnabled = enable;

    return Status::OK;
}

Return<void> ExampleCameraDevice::open(
    const sp<V3_2::ICameraDeviceCallback>& callback,
    open_cb _hidl_cb) {

    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("open called for camera %s", mCameraId.c_str());

    // Check if already open
    if (mIsOpen) {
        ALOGE("Camera %s is already open", mCameraId.c_str());
        _hidl_cb(Status::CAMERA_IN_USE, nullptr);
        return Void();
    }

    // Validate callback
    if (callback == nullptr) {
        ALOGE("Null callback provided");
        _hidl_cb(Status::ILLEGAL_ARGUMENT, nullptr);
        return Void();
    }

    // Turn off torch if it was on
    if (mTorchEnabled) {
        mTorchEnabled = false;
        ALOGI("Turned off torch for camera open");
    }

    // Store callback
    mCallback = callback;

    // Create camera session
    sp<ExampleCameraDeviceSession> session =
        new ExampleCameraDeviceSession(this, callback);

    if (session == nullptr) {
        ALOGE("Failed to create camera session");
        _hidl_cb(Status::INTERNAL_ERROR, nullptr);
        return Void();
    }

    // Initialize session
    if (!session->initialize()) {
        ALOGE("Failed to initialize camera session");
        _hidl_cb(Status::INTERNAL_ERROR, nullptr);
        return Void();
    }

    mSession = session;
    mIsOpen = true;

    ALOGI("Camera %s opened successfully", mCameraId.c_str());
    _hidl_cb(Status::OK, session);
    return Void();
}

Return<void> ExampleCameraDevice::dumpState(const hidl_handle& fd) {
    ALOGI("dumpState called for camera %s", mCameraId.c_str());

    if (fd == nullptr || fd->numFds < 1) {
        ALOGW("Invalid file descriptor for dump");
        return Void();
    }

    int dumpFd = fd->data[0];

    // Write device state to file descriptor
    dprintf(dumpFd, "=== Camera Device %s ===\n", mCameraId.c_str());
    dprintf(dumpFd, "  Facing: %s\n",
            mFacing == CameraFacing::BACK ? "BACK" : "FRONT");
    dprintf(dumpFd, "  Sensor: %dx%d\n", mSensorWidth, mSensorHeight);
    dprintf(dumpFd, "  Has Flash: %s\n", mHasFlash ? "yes" : "no");
    dprintf(dumpFd, "  Is Open: %s\n", mIsOpen.load() ? "yes" : "no");
    dprintf(dumpFd, "  Torch Enabled: %s\n", mTorchEnabled.load() ? "yes" : "no");
    dprintf(dumpFd, "  Hardware Level: %d\n", static_cast<int>(mHardwareLevel));

    return Void();
}

// ============================================================================
// ICameraDevice 3.5 Methods
// ============================================================================

Return<void> ExampleCameraDevice::getPhysicalCameraCharacteristics(
    const hidl_string& physicalCameraId,
    getPhysicalCameraCharacteristics_cb _hidl_cb) {

    ALOGI("getPhysicalCameraCharacteristics called for physical camera %s",
          physicalCameraId.c_str());

    // This simple example doesn't have multiple physical cameras
    // In a multi-camera device, return characteristics for each physical camera
    _hidl_cb(Status::ILLEGAL_ARGUMENT, CameraMetadata());
    return Void();
}

Return<void> ExampleCameraDevice::isStreamCombinationSupported(
    const V3_4::StreamConfiguration& streams,
    isStreamCombinationSupported_cb _hidl_cb) {

    ALOGI("isStreamCombinationSupported called with %zu streams",
          streams.streams.size());

    bool supported = validateStreamConfiguration(streams);
    _hidl_cb(Status::OK, supported);
    return Void();
}

// ============================================================================
// Helper Methods
// ============================================================================

bool ExampleCameraDevice::validateStreamConfiguration(
    const V3_4::StreamConfiguration& config) {

    // Basic validation rules:
    // 1. At least one stream
    // 2. No more than 4 simultaneous streams
    // 3. Resolutions must be supported
    // 4. Formats must be supported

    if (config.streams.size() == 0) {
        ALOGW("Empty stream configuration");
        return false;
    }

    if (config.streams.size() > 4) {
        ALOGW("Too many streams: %zu (max 4)", config.streams.size());
        return false;
    }

    for (const auto& stream : config.streams) {
        // Check resolution
        if (stream.width > mSensorWidth || stream.height > mSensorHeight) {
            ALOGW("Resolution %dx%d exceeds sensor %dx%d",
                  stream.width, stream.height, mSensorWidth, mSensorHeight);
            return false;
        }

        // Check format (simplified)
        switch (stream.format) {
            case HAL_PIXEL_FORMAT_IMPLEMENTATION_DEFINED:
            case HAL_PIXEL_FORMAT_YCbCr_420_888:
            case HAL_PIXEL_FORMAT_BLOB:
            case HAL_PIXEL_FORMAT_RAW16:
                break;
            default:
                ALOGW("Unsupported format: 0x%x", stream.format);
                return false;
        }
    }

    return true;
}

void ExampleCameraDevice::onSessionClosed() {
    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("Session closed for camera %s", mCameraId.c_str());

    mSession = nullptr;
    mCallback = nullptr;
    mIsOpen = false;
}

}  // namespace implementation
}  // namespace V3_5
}  // namespace device
}  // namespace camera
}  // namespace hardware
}  // namespace android

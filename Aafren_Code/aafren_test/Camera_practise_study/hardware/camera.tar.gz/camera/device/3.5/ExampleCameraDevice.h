/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Example Camera Device Implementation
 *
 * This file implements ICameraDevice, representing a single physical camera.
 * The device is responsible for:
 * - Providing camera static characteristics (capabilities, supported formats)
 * - Creating camera sessions when the device is opened
 * - Managing device-level resources
 */

#pragma once

#include <android/hardware/camera/device/3.5/ICameraDevice.h>
#include <android/hardware/camera/device/3.5/ICameraDeviceSession.h>
#include <android/hardware/camera/device/3.5/ICameraDeviceCallback.h>
#include <hidl/MQDescriptor.h>
#include <hidl/Status.h>

#include <atomic>
#include <memory>
#include <mutex>
#include <string>

#include "../common/CameraMetadata.h"

namespace android {
namespace hardware {
namespace camera {
namespace device {
namespace V3_5 {
namespace implementation {

using ::android::sp;
using ::android::hardware::hidl_string;
using ::android::hardware::hidl_vec;
using ::android::hardware::Return;
using ::android::hardware::Void;
using ::android::hardware::camera::common::V1_0::Status;
using ::android::hardware::camera::common::V1_0::TorchMode;
using ::android::hardware::camera::device::V3_2::CameraMetadata;
using ::android::hardware::camera::device::V3_5::ICameraDeviceCallback;

// Forward declaration
class ExampleCameraDeviceSession;

/**
 * Camera Facing Direction
 */
enum class CameraFacing {
    BACK = 0,   // Rear-facing camera
    FRONT = 1,  // Front-facing (selfie) camera
    EXTERNAL = 2 // External USB camera
};

/**
 * Camera Hardware Level
 * Defines the set of features supported by the camera
 */
enum class HardwareLevel {
    LIMITED = 0,   // Basic feature set
    FULL = 1,      // Full HAL3 feature set
    LEGACY = 2,    // Limited to HAL1 equivalent
    LEVEL_3 = 3,   // Extended features (RAW, ZSL)
    EXTERNAL = 4   // External camera limitations
};

/**
 * ExampleCameraDevice
 *
 * Implementation of ICameraDevice HAL interface for a single camera.
 *
 * Responsibilities:
 * 1. Static Characteristics: Report camera capabilities and constraints
 * 2. Session Management: Create/close camera sessions
 * 3. Torch Control: Control flash unit in torch mode
 * 4. Resource Management: Track device open/close state
 *
 * Lifecycle:
 * ┌────────────────────────────────────────────────────────────┐
 * │                    Device States                           │
 * ├────────────────────────────────────────────────────────────┤
 * │                                                            │
 * │   ┌─────────┐    open()     ┌─────────┐                   │
 * │   │  IDLE   │──────────────▶│  OPEN   │                   │
 * │   └─────────┘               └────┬────┘                   │
 * │        ▲                         │                         │
 * │        │      close()            │                         │
 * │        └─────────────────────────┘                         │
 * │                                                            │
 * └────────────────────────────────────────────────────────────┘
 */
class ExampleCameraDevice : public ICameraDevice {
public:
    /**
     * Constructor
     * @param cameraId: Unique identifier for this camera (e.g., "0", "1")
     */
    explicit ExampleCameraDevice(const std::string& cameraId);
    virtual ~ExampleCameraDevice();

    // ========================================================================
    // ICameraDevice Interface Methods (HIDL)
    // ========================================================================

    /**
     * getResourceCost - Get resource cost for camera usage
     *
     * @param _hidl_cb: Callback to return resource cost info
     * @return Void (result via callback)
     *
     * Resource cost is used by the framework to decide which cameras
     * can be opened simultaneously. Cost is 0-100 where 100 means
     * exclusive use of all camera resources.
     */
    Return<void> getResourceCost(getResourceCost_cb _hidl_cb) override;

    /**
     * getCameraCharacteristics - Get camera static metadata
     *
     * @param _hidl_cb: Callback to return characteristics
     * @return Void (result via callback)
     *
     * Returns static information about the camera including:
     * - Sensor size and resolution
     * - Supported stream configurations
     * - 3A capabilities (AE, AF, AWB)
     * - Lens and flash information
     * - Hardware level support
     */
    Return<void> getCameraCharacteristics(
        getCameraCharacteristics_cb _hidl_cb) override;

    /**
     * setTorchMode - Control flash in torch mode
     *
     * @param mode: ON or OFF
     * @return Status indicating success or failure
     *
     * Torch mode allows using the flash as a flashlight when
     * the camera is not actively in use.
     */
    Return<Status> setTorchMode(TorchMode mode) override;

    /**
     * open - Open camera device and create session
     *
     * @param callback: Callback interface for capture results
     * @param _hidl_cb: Callback to return session interface
     * @return Void (result via callback)
     *
     * Opening a device:
     * 1. Validates device is available
     * 2. Allocates hardware resources
     * 3. Creates a session for capture requests
     * 4. Registers callback for result delivery
     */
    Return<void> open(const sp<V3_2::ICameraDeviceCallback>& callback,
                      open_cb _hidl_cb) override;

    /**
     * dumpState - Dump device state for debugging
     *
     * @param fd: File descriptor to write debug info
     * @return Void
     */
    Return<void> dumpState(const hidl_handle& fd) override;

    // ========================================================================
    // ICameraDevice 3.5 Methods
    // ========================================================================

    /**
     * getPhysicalCameraCharacteristics - Get characteristics for physical camera
     *
     * @param physicalCameraId: ID of physical camera in multi-camera device
     * @param _hidl_cb: Callback to return characteristics
     * @return Void (result via callback)
     *
     * Used for multi-camera devices where one logical camera contains
     * multiple physical cameras (e.g., wide + telephoto).
     */
    Return<void> getPhysicalCameraCharacteristics(
        const hidl_string& physicalCameraId,
        getPhysicalCameraCharacteristics_cb _hidl_cb) override;

    /**
     * isStreamCombinationSupported - Check if stream combination is supported
     *
     * @param streams: Proposed stream configuration
     * @param _hidl_cb: Callback to return support status
     * @return Void (result via callback)
     *
     * Allows framework to query support before configuring streams.
     */
    Return<void> isStreamCombinationSupported(
        const V3_4::StreamConfiguration& streams,
        isStreamCombinationSupported_cb _hidl_cb) override;

    // ========================================================================
    // Public Helper Methods
    // ========================================================================

    /**
     * Get camera ID
     */
    const std::string& getCameraId() const { return mCameraId; }

    /**
     * Check if device is open
     */
    bool isOpen() const { return mIsOpen; }

    /**
     * Get camera facing direction
     */
    CameraFacing getFacing() const { return mFacing; }

    /**
     * Notify that session has been closed
     */
    void onSessionClosed();

private:
    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Initialize camera hardware and metadata
     */
    bool initializeCamera();

    /**
     * Build static characteristics metadata
     */
    void buildStaticCharacteristics();

    /**
     * Build default request settings for given template
     */
    CameraMetadata buildDefaultRequestSettings(int32_t templateType);

    /**
     * Check if stream configuration is valid
     */
    bool validateStreamConfiguration(const V3_4::StreamConfiguration& config);

    // ========================================================================
    // Member Variables
    // ========================================================================

    // Camera identifier
    std::string mCameraId;

    // Mutex for thread-safe access
    mutable std::mutex mMutex;

    // Camera facing direction
    CameraFacing mFacing;

    // Hardware support level
    HardwareLevel mHardwareLevel;

    // Static characteristics metadata
    common::CameraMetadataHelper mCharacteristics;

    // Device open state
    std::atomic<bool> mIsOpen;

    // Torch mode state
    std::atomic<bool> mTorchEnabled;

    // Active session (weak reference to avoid circular reference)
    wp<ExampleCameraDeviceSession> mSession;

    // Callback interface
    sp<V3_2::ICameraDeviceCallback> mCallback;

    // Sensor dimensions
    int32_t mSensorWidth;
    int32_t mSensorHeight;

    // Whether camera has flash
    bool mHasFlash;
};

}  // namespace implementation
}  // namespace V3_5
}  // namespace device
}  // namespace camera
}  // namespace hardware
}  // namespace android

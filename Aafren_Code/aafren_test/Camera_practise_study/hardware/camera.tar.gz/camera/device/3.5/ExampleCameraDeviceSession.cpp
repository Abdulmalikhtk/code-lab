/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

#define LOG_TAG "ExampleCameraSession"

#include "ExampleCameraDeviceSession.h"
#include "ExampleCameraDevice.h"

#include <log/log.h>
#include <system/camera_metadata.h>
#include <chrono>

namespace android {
namespace hardware {
namespace camera {
namespace device {
namespace V3_5 {
namespace implementation {

using ::android::hardware::camera::device::V3_2::BufferStatus;
using ::android::hardware::camera::device::V3_2::ErrorCode;
using ::android::hardware::camera::device::V3_2::MsgType;
using ::android::hardware::camera::device::V3_2::StreamType;
using ::android::hardware::camera::device::V3_4::HalStream;
using std::chrono::duration_cast;
using std::chrono::nanoseconds;
using std::chrono::system_clock;

// ============================================================================
// Constants
// ============================================================================

static const int kMaxInflightRequests = 8;
static const int64_t kDefaultExposureTime = 16666666;  // ~16.7ms (60fps)
static const int32_t kDefaultSensitivity = 100;        // ISO 100

// ============================================================================
// Constructor / Destructor
// ============================================================================

ExampleCameraDeviceSession::ExampleCameraDeviceSession(
    ExampleCameraDevice* device,
    const sp<V3_2::ICameraDeviceCallback>& callback)
    : mDevice(device),
      mCallback(callback),
      mStreamsConfigured(false),
      mRunning(false),
      mFrameNumber(0),
      mClosed(false),
      mStreamConfigCounter(0) {

    ALOGI("ExampleCameraDeviceSession created for camera %s",
          device->getCameraId().c_str());

    // Initialize 3A state with defaults
    m3AState.aeMode = ANDROID_CONTROL_AE_MODE_ON;
    m3AState.aeState = ANDROID_CONTROL_AE_STATE_CONVERGED;
    m3AState.exposureTime = kDefaultExposureTime;
    m3AState.sensitivity = kDefaultSensitivity;

    m3AState.afMode = ANDROID_CONTROL_AF_MODE_CONTINUOUS_PICTURE;
    m3AState.afState = ANDROID_CONTROL_AF_STATE_PASSIVE_FOCUSED;
    m3AState.focusDistance = 0.0f;

    m3AState.awbMode = ANDROID_CONTROL_AWB_MODE_AUTO;
    m3AState.awbState = ANDROID_CONTROL_AWB_STATE_CONVERGED;
}

ExampleCameraDeviceSession::~ExampleCameraDeviceSession() {
    ALOGI("ExampleCameraDeviceSession destroyed");

    // Ensure session is closed
    if (!mClosed) {
        close();
    }
}

bool ExampleCameraDeviceSession::initialize() {
    ALOGI("Initializing camera session");

    // Build default request templates
    mDefaultTemplates[RequestTemplate::PREVIEW] = buildPreviewSettings();
    mDefaultTemplates[RequestTemplate::STILL_CAPTURE] = buildStillCaptureSettings();
    mDefaultTemplates[RequestTemplate::VIDEO_RECORD] = buildVideoRecordSettings();
    mDefaultTemplates[RequestTemplate::VIDEO_SNAPSHOT] = buildVideoSnapshotSettings();
    mDefaultTemplates[RequestTemplate::ZERO_SHUTTER_LAG] = buildZslSettings();
    mDefaultTemplates[RequestTemplate::MANUAL] = buildManualSettings();

    // Start request processing thread
    mRunning = true;
    mRequestThread = std::thread(&ExampleCameraDeviceSession::requestThreadLoop, this);

    ALOGI("Camera session initialized");
    return true;
}

// ============================================================================
// ICameraDeviceSession Interface Implementation
// ============================================================================

Return<void> ExampleCameraDeviceSession::constructDefaultRequestSettings(
    RequestTemplate type,
    constructDefaultRequestSettings_cb _hidl_cb) {

    ALOGI("constructDefaultRequestSettings: type=%d", static_cast<int>(type));

    auto it = mDefaultTemplates.find(type);
    if (it != mDefaultTemplates.end()) {
        _hidl_cb(Status::OK, it->second);
    } else {
        ALOGW("Unknown request template type: %d", static_cast<int>(type));
        _hidl_cb(Status::ILLEGAL_ARGUMENT, CameraMetadata());
    }

    return Void();
}

Return<void> ExampleCameraDeviceSession::configureStreams_3_5(
    const V3_5::StreamConfiguration& requestedConfiguration,
    configureStreams_3_5_cb _hidl_cb) {

    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("configureStreams_3_5: %zu streams, counter=%u",
          requestedConfiguration.v3_4.streams.size(),
          requestedConfiguration.streamConfigCounter);

    V3_5::HalStreamConfiguration halConfig;
    halConfig.streams.resize(requestedConfiguration.v3_4.streams.size());

    // Clear existing streams
    mStreams.clear();
    mStreamsConfigured = false;

    // Configure each stream
    for (size_t i = 0; i < requestedConfiguration.v3_4.streams.size(); i++) {
        const auto& stream = requestedConfiguration.v3_4.streams[i].v3_2;

        ALOGI("  Stream %zu: id=%d, %dx%d, format=0x%x, usage=0x%x",
              i, stream.id, stream.width, stream.height,
              stream.format, stream.usage);

        // Create stream info
        StreamInfo info;
        Status status = configureStream(stream, info);
        if (status != Status::OK) {
            ALOGE("Failed to configure stream %d", stream.id);
            _hidl_cb(status, halConfig);
            return Void();
        }

        mStreams[stream.id] = info;

        // Fill HAL stream configuration
        halConfig.streams[i].v3_4.v3_3.v3_2.id = stream.id;
        halConfig.streams[i].v3_4.v3_3.v3_2.overrideFormat = stream.format;
        halConfig.streams[i].v3_4.v3_3.v3_2.producerUsage = 0;
        halConfig.streams[i].v3_4.v3_3.v3_2.consumerUsage = stream.usage;
        halConfig.streams[i].v3_4.v3_3.v3_2.maxBuffers = info.maxBuffers;
        halConfig.streams[i].v3_4.physicalCameraId = "";
        halConfig.streams[i].supportOffline = false;
    }

    mStreamConfigCounter = requestedConfiguration.streamConfigCounter;
    mStreamsConfigured = true;

    ALOGI("Configured %zu streams successfully", mStreams.size());
    _hidl_cb(Status::OK, halConfig);
    return Void();
}

Return<void> ExampleCameraDeviceSession::processCaptureRequest_3_4(
    const hidl_vec<V3_4::CaptureRequest>& requests,
    const hidl_vec<BufferCache>& cachesToRemove,
    processCaptureRequest_3_4_cb _hidl_cb) {

    if (mClosed) {
        ALOGE("Session is closed");
        _hidl_cb(Status::INTERNAL_ERROR, 0);
        return Void();
    }

    if (!mStreamsConfigured) {
        ALOGE("Streams not configured");
        _hidl_cb(Status::INTERNAL_ERROR, 0);
        return Void();
    }

    ALOGV("processCaptureRequest_3_4: %zu requests", requests.size());

    uint32_t numProcessed = 0;

    for (const auto& request : requests) {
        const auto& v3_2Request = request.v3_2;

        // Validate request
        if (v3_2Request.outputBuffers.size() == 0) {
            ALOGE("Request has no output buffers");
            continue;
        }

        // Create pending request
        PendingRequest pendingRequest;
        pendingRequest.frameNumber = v3_2Request.frameNumber;
        pendingRequest.settings = v3_2Request.settings;

        // Collect output stream IDs
        for (const auto& buffer : v3_2Request.outputBuffers) {
            pendingRequest.streamIds.push_back(buffer.streamId);
            pendingRequest.outputBuffers.push_back(buffer.buffer.getNativeHandle());
        }

        // Queue request for processing
        {
            std::lock_guard<std::mutex> lock(mRequestMutex);
            mPendingRequests.push_back(std::move(pendingRequest));
        }
        mRequestCond.notify_one();

        numProcessed++;
        ALOGV("Queued request: frameNumber=%u", v3_2Request.frameNumber);
    }

    _hidl_cb(Status::OK, numProcessed);
    return Void();
}

Return<void> ExampleCameraDeviceSession::signalStreamFlush(
    const hidl_vec<int32_t>& streamIds,
    uint32_t streamConfigCounter) {

    ALOGI("signalStreamFlush: %zu streams, counter=%u",
          streamIds.size(), streamConfigCounter);

    // Flush pending requests for specified streams
    flush();

    return Void();
}

Return<void> ExampleCameraDeviceSession::isReconfigurationRequired(
    const CameraMetadata& oldSessionParams,
    const CameraMetadata& newSessionParams,
    isReconfigurationRequired_cb _hidl_cb) {

    // For this example, always require reconfiguration
    // In production, compare session parameters to determine if needed
    _hidl_cb(Status::OK, true);
    return Void();
}

Return<Status> ExampleCameraDeviceSession::flush() {
    ALOGI("flush called");

    std::lock_guard<std::mutex> lock(mRequestMutex);

    // Cancel all pending requests
    while (!mPendingRequests.empty()) {
        PendingRequest& request = mPendingRequests.front();

        // Send error notification for cancelled request
        sendErrorNotify(request.frameNumber,
                        static_cast<int32_t>(ErrorCode::ERROR_REQUEST));

        mPendingRequests.pop_front();
    }

    return Status::OK;
}

Return<Status> ExampleCameraDeviceSession::close() {
    ALOGI("close called");

    if (mClosed.exchange(true)) {
        ALOGW("Session already closed");
        return Status::OK;
    }

    // Stop request thread
    mRunning = false;
    mRequestCond.notify_all();

    if (mRequestThread.joinable()) {
        mRequestThread.join();
    }

    // Clear streams
    {
        std::lock_guard<std::mutex> lock(mMutex);
        mStreams.clear();
        mStreamsConfigured = false;
    }

    // Notify device that session is closed
    if (mDevice) {
        mDevice->onSessionClosed();
    }

    ALOGI("Session closed");
    return Status::OK;
}

// ============================================================================
// Legacy Methods (V3_2/V3_3/V3_4 compatibility)
// ============================================================================

Return<void> ExampleCameraDeviceSession::configureStreams(
    const V3_2::StreamConfiguration& requestedConfiguration,
    configureStreams_cb _hidl_cb) {

    // Convert to V3_4 and call newer implementation
    V3_4::StreamConfiguration config34;
    config34.streams.resize(requestedConfiguration.streams.size());

    for (size_t i = 0; i < requestedConfiguration.streams.size(); i++) {
        config34.streams[i].v3_2 = requestedConfiguration.streams[i];
    }
    config34.operationMode = requestedConfiguration.operationMode;

    V3_5::StreamConfiguration config35;
    config35.v3_4 = config34;
    config35.streamConfigCounter = ++mStreamConfigCounter;

    configureStreams_3_5(config35, [&](Status status, const V3_5::HalStreamConfiguration& halConfig) {
        V3_2::HalStreamConfiguration config32;
        config32.streams.resize(halConfig.streams.size());
        for (size_t i = 0; i < halConfig.streams.size(); i++) {
            config32.streams[i] = halConfig.streams[i].v3_4.v3_3.v3_2;
        }
        _hidl_cb(status, config32);
    });

    return Void();
}

Return<void> ExampleCameraDeviceSession::configureStreams_3_3(
    const V3_2::StreamConfiguration& requestedConfiguration,
    configureStreams_3_3_cb _hidl_cb) {

    configureStreams(requestedConfiguration, [&](Status status, const V3_2::HalStreamConfiguration& config) {
        V3_3::HalStreamConfiguration config33;
        config33.streams.resize(config.streams.size());
        for (size_t i = 0; i < config.streams.size(); i++) {
            config33.streams[i].v3_2 = config.streams[i];
        }
        _hidl_cb(status, config33);
    });

    return Void();
}

Return<void> ExampleCameraDeviceSession::configureStreams_3_4(
    const V3_4::StreamConfiguration& requestedConfiguration,
    configureStreams_3_4_cb _hidl_cb) {

    V3_5::StreamConfiguration config35;
    config35.v3_4 = requestedConfiguration;
    config35.streamConfigCounter = ++mStreamConfigCounter;

    configureStreams_3_5(config35, [&](Status status, const V3_5::HalStreamConfiguration& halConfig) {
        V3_4::HalStreamConfiguration config34;
        config34.streams.resize(halConfig.streams.size());
        for (size_t i = 0; i < halConfig.streams.size(); i++) {
            config34.streams[i] = halConfig.streams[i].v3_4;
        }
        _hidl_cb(status, config34);
    });

    return Void();
}

Return<void> ExampleCameraDeviceSession::processCaptureRequest(
    const hidl_vec<CaptureRequest>& requests,
    const hidl_vec<BufferCache>& cachesToRemove,
    processCaptureRequest_cb _hidl_cb) {

    // Convert to V3_4 requests
    hidl_vec<V3_4::CaptureRequest> requests34;
    requests34.resize(requests.size());

    for (size_t i = 0; i < requests.size(); i++) {
        requests34[i].v3_2 = requests[i];
    }

    processCaptureRequest_3_4(requests34, cachesToRemove,
        [&](Status status, uint32_t numProcessed) {
            _hidl_cb(status, numProcessed);
        });

    return Void();
}

Return<void> ExampleCameraDeviceSession::getCaptureRequestMetadataQueue(
    getCaptureRequestMetadataQueue_cb _hidl_cb) {

    // Return empty descriptor (not using FMQ for this example)
    _hidl_cb(*mRequestMetadataQueue->getDesc());
    return Void();
}

Return<void> ExampleCameraDeviceSession::getCaptureResultMetadataQueue(
    getCaptureResultMetadataQueue_cb _hidl_cb) {

    // Return empty descriptor (not using FMQ for this example)
    _hidl_cb(*mResultMetadataQueue->getDesc());
    return Void();
}

// ============================================================================
// Request Processing
// ============================================================================

void ExampleCameraDeviceSession::requestThreadLoop() {
    ALOGI("Request processing thread started");

    while (mRunning) {
        PendingRequest request;

        // Wait for request
        {
            std::unique_lock<std::mutex> lock(mRequestMutex);
            mRequestCond.wait(lock, [this] {
                return !mPendingRequests.empty() || !mRunning;
            });

            if (!mRunning) {
                break;
            }

            if (mPendingRequests.empty()) {
                continue;
            }

            request = std::move(mPendingRequests.front());
            mPendingRequests.pop_front();
        }

        // Process the request
        processOneRequest(request);
    }

    ALOGI("Request processing thread stopped");
}

void ExampleCameraDeviceSession::processOneRequest(const PendingRequest& request) {
    ALOGV("Processing request: frameNumber=%u", request.frameNumber);

    // Get current timestamp
    auto now = system_clock::now();
    auto timestamp = duration_cast<nanoseconds>(now.time_since_epoch()).count();

    // Create mutable copy for 3A processing
    PendingRequest mutableRequest = request;
    mutableRequest.timestamp = timestamp;

    // Send shutter notification
    sendShutterNotify(request.frameNumber, timestamp);

    // Run 3A algorithms
    run3A(mutableRequest);

    // Simulate capture (in real HAL, this would trigger hardware)
    simulateCapture(mutableRequest);

    // Send capture result
    sendCaptureResult(mutableRequest);

    ALOGV("Completed request: frameNumber=%u", request.frameNumber);
}

void ExampleCameraDeviceSession::run3A(PendingRequest& request) {
    // Simulate 3A algorithm execution
    // In a real HAL, this would:
    // 1. Analyze image statistics
    // 2. Adjust exposure, focus, white balance
    // 3. Update state machines

    // AE: Simulate exposure convergence
    if (m3AState.aeMode == ANDROID_CONTROL_AE_MODE_ON) {
        // Simulate exposure adjustment
        m3AState.aeState = ANDROID_CONTROL_AE_STATE_CONVERGED;
    }

    // AF: Simulate focus
    if (m3AState.afMode == ANDROID_CONTROL_AF_MODE_CONTINUOUS_PICTURE) {
        m3AState.afState = ANDROID_CONTROL_AF_STATE_PASSIVE_FOCUSED;
    }

    // AWB: Simulate white balance
    if (m3AState.awbMode == ANDROID_CONTROL_AWB_MODE_AUTO) {
        m3AState.awbState = ANDROID_CONTROL_AWB_STATE_CONVERGED;
    }
}

void ExampleCameraDeviceSession::simulateCapture(const PendingRequest& request) {
    // Simulate capture latency (real HAL would trigger sensor exposure)
    // This is where hardware would be programmed with settings

    // Simulate some processing time
    std::this_thread::sleep_for(std::chrono::milliseconds(1));

    // In a real implementation:
    // 1. Program sensor with exposure settings
    // 2. Wait for frame to be captured
    // 3. Run ISP processing
    // 4. Output processed frame to buffers
}

// ============================================================================
// Result Delivery
// ============================================================================

void ExampleCameraDeviceSession::sendShutterNotify(uint32_t frameNumber,
                                                    int64_t timestamp) {
    if (!mCallback) {
        ALOGE("No callback registered");
        return;
    }

    NotifyMsg msg;
    msg.type = MsgType::SHUTTER;
    msg.msg.shutter.frameNumber = frameNumber;
    msg.msg.shutter.timestamp = timestamp;

    hidl_vec<NotifyMsg> msgs(1);
    msgs[0] = msg;

    mCallback->notify(msgs);
}

void ExampleCameraDeviceSession::sendErrorNotify(uint32_t frameNumber,
                                                  int32_t errorCode) {
    if (!mCallback) {
        return;
    }

    NotifyMsg msg;
    msg.type = MsgType::ERROR;
    msg.msg.error.frameNumber = frameNumber;
    msg.msg.error.errorCode = static_cast<ErrorCode>(errorCode);
    msg.msg.error.errorStreamId = -1;

    hidl_vec<NotifyMsg> msgs(1);
    msgs[0] = msg;

    mCallback->notify(msgs);
}

void ExampleCameraDeviceSession::sendCaptureResult(const PendingRequest& request) {
    if (!mCallback) {
        ALOGE("No callback registered");
        return;
    }

    // Build result metadata
    camera_metadata_t* resultMeta = allocate_camera_metadata(32, 256);
    if (!resultMeta) {
        ALOGE("Failed to allocate result metadata");
        return;
    }

    // Add timestamp
    add_camera_metadata_entry(resultMeta, ANDROID_SENSOR_TIMESTAMP,
                              &request.timestamp, 1);

    // Add 3A states
    add_camera_metadata_entry(resultMeta, ANDROID_CONTROL_AE_STATE,
                              &m3AState.aeState, 1);
    add_camera_metadata_entry(resultMeta, ANDROID_CONTROL_AF_STATE,
                              &m3AState.afState, 1);
    add_camera_metadata_entry(resultMeta, ANDROID_CONTROL_AWB_STATE,
                              &m3AState.awbState, 1);

    // Add exposure info
    add_camera_metadata_entry(resultMeta, ANDROID_SENSOR_EXPOSURE_TIME,
                              &m3AState.exposureTime, 1);
    add_camera_metadata_entry(resultMeta, ANDROID_SENSOR_SENSITIVITY,
                              &m3AState.sensitivity, 1);

    // Convert to HIDL metadata
    CameraMetadata hidlMeta;
    size_t metaSize = get_camera_metadata_size(resultMeta);
    hidlMeta.resize(metaSize);
    memcpy(hidlMeta.data(), resultMeta, metaSize);

    // Build capture result
    CaptureResult result;
    result.frameNumber = request.frameNumber;
    result.partialResult = 1;  // Single partial result
    result.result = hidlMeta;

    // Build output buffers
    result.outputBuffers.resize(request.streamIds.size());
    for (size_t i = 0; i < request.streamIds.size(); i++) {
        result.outputBuffers[i].streamId = request.streamIds[i];
        result.outputBuffers[i].bufferId = 0;  // Use buffer from request
        result.outputBuffers[i].status = BufferStatus::OK;
        result.outputBuffers[i].acquireFence = nullptr;
        result.outputBuffers[i].releaseFence = nullptr;
    }

    // No input buffer for output-only requests
    result.inputBuffer.streamId = -1;

    // Send result
    hidl_vec<CaptureResult> results(1);
    results[0] = result;

    mCallback->processCaptureResult(results);

    free_camera_metadata(resultMeta);
}

// ============================================================================
// Stream Management
// ============================================================================

Status ExampleCameraDeviceSession::configureStream(const Stream& stream,
                                                    StreamInfo& info) {
    info.id = stream.id;
    info.width = stream.width;
    info.height = stream.height;
    info.format = stream.format;
    info.usage = stream.usage;
    info.dataSpace = stream.dataSpace;
    info.rotation = static_cast<int32_t>(stream.rotation);
    info.isConfigured = true;

    // Determine max buffers based on stream type
    // More buffers = better pipelining, but more memory
    if (stream.format == HAL_PIXEL_FORMAT_BLOB) {
        // JPEG: fewer buffers needed
        info.maxBuffers = 2;
    } else {
        // Preview/video: more buffers for smooth operation
        info.maxBuffers = 4;
    }

    return Status::OK;
}

bool ExampleCameraDeviceSession::validateStreamConfig(
    const hidl_vec<Stream>& streams) {

    if (streams.size() == 0) {
        ALOGE("No streams provided");
        return false;
    }

    if (streams.size() > 4) {
        ALOGE("Too many streams: %zu", streams.size());
        return false;
    }

    return true;
}

// ============================================================================
// Default Settings Builders
// ============================================================================

CameraMetadata ExampleCameraDeviceSession::buildPreviewSettings() {
    camera_metadata_t* meta = allocate_camera_metadata(64, 512);

    // Control mode: Auto
    uint8_t controlMode = ANDROID_CONTROL_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_MODE, &controlMode, 1);

    // AE: Auto exposure on
    uint8_t aeMode = ANDROID_CONTROL_AE_MODE_ON;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_MODE, &aeMode, 1);

    // AF: Continuous picture
    uint8_t afMode = ANDROID_CONTROL_AF_MODE_CONTINUOUS_PICTURE;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AF_MODE, &afMode, 1);

    // AWB: Auto
    uint8_t awbMode = ANDROID_CONTROL_AWB_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AWB_MODE, &awbMode, 1);

    // Convert to HIDL format
    CameraMetadata hidlMeta;
    size_t size = get_camera_metadata_size(meta);
    hidlMeta.resize(size);
    memcpy(hidlMeta.data(), meta, size);

    free_camera_metadata(meta);
    return hidlMeta;
}

CameraMetadata ExampleCameraDeviceSession::buildStillCaptureSettings() {
    camera_metadata_t* meta = allocate_camera_metadata(64, 512);

    // Control mode: Auto
    uint8_t controlMode = ANDROID_CONTROL_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_MODE, &controlMode, 1);

    // AE: Auto with flash if available
    uint8_t aeMode = ANDROID_CONTROL_AE_MODE_ON_AUTO_FLASH;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_MODE, &aeMode, 1);

    // AF: Auto (for still capture, want best focus)
    uint8_t afMode = ANDROID_CONTROL_AF_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AF_MODE, &afMode, 1);

    // AWB: Auto
    uint8_t awbMode = ANDROID_CONTROL_AWB_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AWB_MODE, &awbMode, 1);

    // High quality JPEG
    uint8_t jpegQuality = 95;
    add_camera_metadata_entry(meta, ANDROID_JPEG_QUALITY, &jpegQuality, 1);

    // Convert to HIDL format
    CameraMetadata hidlMeta;
    size_t size = get_camera_metadata_size(meta);
    hidlMeta.resize(size);
    memcpy(hidlMeta.data(), meta, size);

    free_camera_metadata(meta);
    return hidlMeta;
}

CameraMetadata ExampleCameraDeviceSession::buildVideoRecordSettings() {
    camera_metadata_t* meta = allocate_camera_metadata(64, 512);

    // Control mode: Auto
    uint8_t controlMode = ANDROID_CONTROL_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_MODE, &controlMode, 1);

    // AE: Auto
    uint8_t aeMode = ANDROID_CONTROL_AE_MODE_ON;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_MODE, &aeMode, 1);

    // AF: Continuous video (smooth transitions)
    uint8_t afMode = ANDROID_CONTROL_AF_MODE_CONTINUOUS_VIDEO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AF_MODE, &afMode, 1);

    // AWB: Auto
    uint8_t awbMode = ANDROID_CONTROL_AWB_MODE_AUTO;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AWB_MODE, &awbMode, 1);

    // Video stabilization mode
    uint8_t vstabMode = ANDROID_CONTROL_VIDEO_STABILIZATION_MODE_ON;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_VIDEO_STABILIZATION_MODE,
                              &vstabMode, 1);

    // Convert to HIDL format
    CameraMetadata hidlMeta;
    size_t size = get_camera_metadata_size(meta);
    hidlMeta.resize(size);
    memcpy(hidlMeta.data(), meta, size);

    free_camera_metadata(meta);
    return hidlMeta;
}

CameraMetadata ExampleCameraDeviceSession::buildVideoSnapshotSettings() {
    // Video snapshot similar to video record but optimized for stills
    return buildVideoRecordSettings();
}

CameraMetadata ExampleCameraDeviceSession::buildZslSettings() {
    // ZSL (Zero Shutter Lag) settings
    return buildPreviewSettings();
}

CameraMetadata ExampleCameraDeviceSession::buildManualSettings() {
    camera_metadata_t* meta = allocate_camera_metadata(64, 512);

    // Control mode: Off (full manual)
    uint8_t controlMode = ANDROID_CONTROL_MODE_OFF;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_MODE, &controlMode, 1);

    // AE: Off
    uint8_t aeMode = ANDROID_CONTROL_AE_MODE_OFF;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AE_MODE, &aeMode, 1);

    // AF: Off
    uint8_t afMode = ANDROID_CONTROL_AF_MODE_OFF;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AF_MODE, &afMode, 1);

    // AWB: Off
    uint8_t awbMode = ANDROID_CONTROL_AWB_MODE_OFF;
    add_camera_metadata_entry(meta, ANDROID_CONTROL_AWB_MODE, &awbMode, 1);

    // Default manual exposure
    int64_t exposureTime = kDefaultExposureTime;
    add_camera_metadata_entry(meta, ANDROID_SENSOR_EXPOSURE_TIME,
                              &exposureTime, 1);

    // Default sensitivity
    int32_t sensitivity = kDefaultSensitivity;
    add_camera_metadata_entry(meta, ANDROID_SENSOR_SENSITIVITY,
                              &sensitivity, 1);

    // Convert to HIDL format
    CameraMetadata hidlMeta;
    size_t size = get_camera_metadata_size(meta);
    hidlMeta.resize(size);
    memcpy(hidlMeta.data(), meta, size);

    free_camera_metadata(meta);
    return hidlMeta;
}

}  // namespace implementation
}  // namespace V3_5
}  // namespace device
}  // namespace camera
}  // namespace hardware
}  // namespace android

/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Example Camera Device Session Implementation
 *
 * ICameraDeviceSession handles active camera operations:
 * - Stream configuration (preview, video, still capture)
 * - Capture request processing
 * - 3A (AE/AF/AWB) algorithm execution
 * - Result delivery to the framework
 */

#pragma once

#include <android/hardware/camera/device/3.5/ICameraDeviceSession.h>
#include <android/hardware/camera/device/3.5/ICameraDeviceCallback.h>
#include <fmq/MessageQueue.h>
#include <hidl/MQDescriptor.h>
#include <hidl/Status.h>

#include <atomic>
#include <condition_variable>
#include <deque>
#include <map>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

#include "../common/CameraMetadata.h"

namespace android {
namespace hardware {
namespace camera {
namespace device {
namespace V3_5 {
namespace implementation {

using ::android::sp;
using ::android::hardware::hidl_handle;
using ::android::hardware::hidl_string;
using ::android::hardware::hidl_vec;
using ::android::hardware::Return;
using ::android::hardware::Void;
using ::android::hardware::camera::common::V1_0::Status;
using ::android::hardware::camera::device::V3_2::BufferCache;
using ::android::hardware::camera::device::V3_2::CameraMetadata;
using ::android::hardware::camera::device::V3_2::CaptureRequest;
using ::android::hardware::camera::device::V3_2::CaptureResult;
using ::android::hardware::camera::device::V3_2::NotifyMsg;
using ::android::hardware::camera::device::V3_2::RequestTemplate;
using ::android::hardware::camera::device::V3_2::Stream;
using ::android::hardware::camera::device::V3_2::StreamBuffer;
using ::android::hardware::camera::device::V3_2::StreamConfiguration;
using ::android::hardware::camera::device::V3_4::HalStreamConfiguration;
using ::android::hardware::MessageQueue;

// Forward declaration
class ExampleCameraDevice;

/**
 * Stream State Information
 * Tracks configuration and buffers for each configured stream
 */
struct StreamInfo {
    int32_t id;                     // Stream ID
    int32_t width;                  // Stream width
    int32_t height;                 // Stream height
    int32_t format;                 // Pixel format
    uint32_t usage;                 // Gralloc usage flags
    int32_t dataSpace;              // Data space (e.g., sRGB, BT2020)
    int32_t rotation;               // Rotation (0, 90, 180, 270)
    uint32_t maxBuffers;            // Maximum number of buffers

    // Buffer management
    std::vector<buffer_handle_t> buffers;
    bool isConfigured;
};

/**
 * Pending Capture Request
 * Contains all information needed to process a capture request
 */
struct PendingRequest {
    uint32_t frameNumber;           // Unique frame identifier
    CameraMetadata settings;        // Capture settings
    std::vector<int32_t> streamIds; // Output streams for this request
    std::vector<buffer_handle_t> outputBuffers;
    int64_t timestamp;              // Capture timestamp (ns)
};

/**
 * 3A State
 * Tracks state of auto-exposure, auto-focus, and auto-white-balance
 */
struct ThreeAState {
    // AE (Auto Exposure)
    uint8_t aeMode;
    uint8_t aeState;
    int64_t exposureTime;           // Current exposure time (ns)
    int32_t sensitivity;            // Current ISO

    // AF (Auto Focus)
    uint8_t afMode;
    uint8_t afState;
    float focusDistance;            // Current focus distance

    // AWB (Auto White Balance)
    uint8_t awbMode;
    uint8_t awbState;
};

/**
 * ExampleCameraDeviceSession
 *
 * Implementation of ICameraDeviceSession for active camera operations.
 *
 * Request Pipeline:
 * ┌─────────────────────────────────────────────────────────────────┐
 * │                     Request Processing Pipeline                 │
 * ├─────────────────────────────────────────────────────────────────┤
 * │                                                                  │
 * │   App Request                                                    │
 * │       │                                                          │
 * │       ▼                                                          │
 * │   ┌──────────────────┐                                          │
 * │   │ processCaptureReq│  Validate & queue request                │
 * │   └────────┬─────────┘                                          │
 * │            │                                                     │
 * │            ▼                                                     │
 * │   ┌──────────────────┐                                          │
 * │   │  Request Thread  │  Dequeue & process requests              │
 * │   └────────┬─────────┘                                          │
 * │            │                                                     │
 * │            ├──────────────┐                                      │
 * │            ▼              ▼                                      │
 * │   ┌──────────────┐  ┌──────────────┐                            │
 * │   │ 3A Processing│  │ ISP/Sensor   │  Simulated hardware        │
 * │   └──────────────┘  └──────────────┘                            │
 * │            │              │                                      │
 * │            └──────┬───────┘                                      │
 * │                   ▼                                              │
 * │   ┌──────────────────┐                                          │
 * │   │  Result Thread   │  Deliver results to framework            │
 * │   └────────┬─────────┘                                          │
 * │            │                                                     │
 * │            ▼                                                     │
 * │   ┌──────────────────┐                                          │
 * │   │ CaptureResult    │  Metadata + buffers                      │
 * │   └──────────────────┘                                          │
 * │                                                                  │
 * └─────────────────────────────────────────────────────────────────┘
 */
class ExampleCameraDeviceSession : public ICameraDeviceSession {
public:
    /**
     * Constructor
     * @param device: Parent camera device
     * @param callback: Callback for delivering results
     */
    ExampleCameraDeviceSession(
        ExampleCameraDevice* device,
        const sp<V3_2::ICameraDeviceCallback>& callback);

    virtual ~ExampleCameraDeviceSession();

    // ========================================================================
    // ICameraDeviceSession Interface Methods (HIDL)
    // ========================================================================

    /**
     * constructDefaultRequestSettings - Get default settings for template
     *
     * @param type: Request template type (PREVIEW, STILL_CAPTURE, VIDEO, etc.)
     * @param _hidl_cb: Callback to return settings
     * @return Void (result via callback)
     *
     * Templates provide optimized default settings for common use cases:
     * - PREVIEW: Optimized for viewfinder display
     * - STILL_CAPTURE: Optimized for still image quality
     * - VIDEO_RECORD: Optimized for video recording
     * - VIDEO_SNAPSHOT: Still capture during video
     * - ZERO_SHUTTER_LAG: For ZSL capture
     * - MANUAL: Starting point for manual control
     */
    Return<void> constructDefaultRequestSettings(
        RequestTemplate type,
        constructDefaultRequestSettings_cb _hidl_cb) override;

    /**
     * configureStreams_3_5 - Configure output streams
     *
     * @param requestedConfiguration: Streams to configure
     * @param _hidl_cb: Callback to return HAL stream configuration
     * @return Void (result via callback)
     *
     * Configures the camera hardware for the requested streams:
     * 1. Validate stream configuration
     * 2. Allocate ISP pipelines
     * 3. Configure buffer allocation
     * 4. Return HAL-specific stream info
     */
    Return<void> configureStreams_3_5(
        const V3_5::StreamConfiguration& requestedConfiguration,
        configureStreams_3_5_cb _hidl_cb) override;

    /**
     * processCaptureRequest_3_4 - Submit capture request
     *
     * @param requests: Vector of capture requests
     * @param cachesToRemove: Buffer caches to invalidate
     * @param _hidl_cb: Callback to return number processed
     * @return Void (result via callback)
     *
     * Submits one or more capture requests to the pipeline:
     * 1. Validate request parameters
     * 2. Queue to processing thread
     * 3. Return immediately (async processing)
     */
    Return<void> processCaptureRequest_3_4(
        const hidl_vec<V3_4::CaptureRequest>& requests,
        const hidl_vec<BufferCache>& cachesToRemove,
        processCaptureRequest_3_4_cb _hidl_cb) override;

    /**
     * signalStreamFlush - Signal that stream flush is needed
     *
     * @param streamIds: Streams to flush
     * @param streamConfigCounter: Configuration counter
     * @return Void
     *
     * Called before reconfiguring streams. HAL should finish or
     * cancel pending requests for the specified streams.
     */
    Return<void> signalStreamFlush(
        const hidl_vec<int32_t>& streamIds,
        uint32_t streamConfigCounter) override;

    /**
     * isReconfigurationRequired - Check if reconfiguration needed
     *
     * @param oldSessionParams: Previous session parameters
     * @param newSessionParams: New session parameters
     * @param _hidl_cb: Callback to return result
     * @return Void (result via callback)
     *
     * Allows HAL to indicate if full reconfiguration is needed
     * when only session parameters change.
     */
    Return<void> isReconfigurationRequired(
        const CameraMetadata& oldSessionParams,
        const CameraMetadata& newSessionParams,
        isReconfigurationRequired_cb _hidl_cb) override;

    /**
     * flush - Flush all pending requests
     *
     * @return Status indicating success or failure
     *
     * Cancels all pending capture requests. Called before:
     * - Closing the camera
     * - Major mode changes
     * - Error recovery
     */
    Return<Status> flush() override;

    /**
     * close - Close the session
     *
     * @return Status indicating success or failure
     *
     * Releases all resources:
     * - Stops processing threads
     * - Frees hardware resources
     * - Clears buffer references
     */
    Return<Status> close() override;

    // ========================================================================
    // Legacy/Compatibility Methods (V3_2/V3_3)
    // ========================================================================

    Return<void> configureStreams(
        const V3_2::StreamConfiguration& requestedConfiguration,
        configureStreams_cb _hidl_cb) override;

    Return<void> configureStreams_3_3(
        const V3_2::StreamConfiguration& requestedConfiguration,
        configureStreams_3_3_cb _hidl_cb) override;

    Return<void> configureStreams_3_4(
        const V3_4::StreamConfiguration& requestedConfiguration,
        configureStreams_3_4_cb _hidl_cb) override;

    Return<void> processCaptureRequest(
        const hidl_vec<CaptureRequest>& requests,
        const hidl_vec<BufferCache>& cachesToRemove,
        processCaptureRequest_cb _hidl_cb) override;

    Return<void> getCaptureRequestMetadataQueue(
        getCaptureRequestMetadataQueue_cb _hidl_cb) override;

    Return<void> getCaptureResultMetadataQueue(
        getCaptureResultMetadataQueue_cb _hidl_cb) override;

    // ========================================================================
    // Public Helper Methods
    // ========================================================================

    /**
     * Initialize the session
     * @return true if initialization succeeded
     */
    bool initialize();

private:
    // ========================================================================
    // Request Processing
    // ========================================================================

    /**
     * Request processing thread function
     */
    void requestThreadLoop();

    /**
     * Process a single capture request
     */
    void processOneRequest(const PendingRequest& request);

    /**
     * Run 3A algorithms on frame
     */
    void run3A(PendingRequest& request);

    /**
     * Simulate image capture
     */
    void simulateCapture(const PendingRequest& request);

    // ========================================================================
    // Result Delivery
    // ========================================================================

    /**
     * Build and send capture result
     */
    void sendCaptureResult(const PendingRequest& request);

    /**
     * Send shutter notification
     */
    void sendShutterNotify(uint32_t frameNumber, int64_t timestamp);

    /**
     * Send error notification
     */
    void sendErrorNotify(uint32_t frameNumber, int32_t errorCode);

    // ========================================================================
    // Stream Management
    // ========================================================================

    /**
     * Configure a single stream
     */
    Status configureStream(const Stream& stream, StreamInfo& info);

    /**
     * Validate stream configuration
     */
    bool validateStreamConfig(const hidl_vec<Stream>& streams);

    // ========================================================================
    // Default Settings Builders
    // ========================================================================

    CameraMetadata buildPreviewSettings();
    CameraMetadata buildStillCaptureSettings();
    CameraMetadata buildVideoRecordSettings();
    CameraMetadata buildVideoSnapshotSettings();
    CameraMetadata buildZslSettings();
    CameraMetadata buildManualSettings();

    // ========================================================================
    // Member Variables
    // ========================================================================

    // Parent device
    ExampleCameraDevice* mDevice;

    // Callback for result delivery
    sp<V3_2::ICameraDeviceCallback> mCallback;

    // Mutex for thread-safe access
    mutable std::mutex mMutex;

    // Stream configuration
    std::map<int32_t, StreamInfo> mStreams;
    bool mStreamsConfigured;

    // Request processing
    std::thread mRequestThread;
    std::atomic<bool> mRunning;
    std::deque<PendingRequest> mPendingRequests;
    std::condition_variable mRequestCond;
    std::mutex mRequestMutex;

    // Frame counter
    std::atomic<uint32_t> mFrameNumber;

    // 3A state
    ThreeAState m3AState;

    // Session state
    std::atomic<bool> mClosed;

    // Configuration counter
    uint32_t mStreamConfigCounter;

    // Message queues for metadata (optional, for performance)
    std::unique_ptr<MessageQueue<uint8_t, kSynchronizedReadWrite>> mRequestMetadataQueue;
    std::unique_ptr<MessageQueue<uint8_t, kSynchronizedReadWrite>> mResultMetadataQueue;

    // Default request templates
    std::map<RequestTemplate, CameraMetadata> mDefaultTemplates;
};

}  // namespace implementation
}  // namespace V3_5
}  // namespace device
}  // namespace camera
}  // namespace hardware
}  // namespace android

/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

#define LOG_TAG "ExampleCameraProvider"

#include "ExampleCameraProvider.h"
#include "../device/3.5/ExampleCameraDevice.h"

#include <log/log.h>
#include <regex>

namespace android {
namespace hardware {
namespace camera {
namespace provider {
namespace V2_7 {
namespace implementation {

// ============================================================================
// Constants
// ============================================================================

// Device name format: "device@<version>/<type>/<id>"
static const char* kDeviceVersion = "3.5";
static const char* kDeviceType = "internal";

// Number of simulated cameras (2 for back + front)
static const int kNumCameras = 2;

// ============================================================================
// Constructor / Destructor
// ============================================================================

ExampleCameraProvider::ExampleCameraProvider()
    : mCallback(nullptr),
      mInitialized(false),
      mDeviceState(0) {
    ALOGI("ExampleCameraProvider created");
}

ExampleCameraProvider::~ExampleCameraProvider() {
    ALOGI("ExampleCameraProvider destroyed");
}

// ============================================================================
// Initialization
// ============================================================================

bool ExampleCameraProvider::initialize() {
    std::lock_guard<std::mutex> lock(mMutex);

    if (mInitialized) {
        ALOGW("Provider already initialized");
        return true;
    }

    ALOGI("Initializing ExampleCameraProvider");

    // Discover available cameras
    discoverCameras();

    // Initialize vendor tags (example custom tags)
    VendorTagSection section;
    section.sectionName = "com.meta.camera";

    // Example vendor tag entries
    hidl_vec<::android::hardware::camera::common::V1_0::VendorTag> tags(2);

    tags[0].tagId = 0x80000000;  // Start of vendor tag range
    tags[0].tagName = "nightModeEnabled";
    tags[0].tagType = ::android::hardware::camera::common::V1_0::CameraMetadataType::BYTE;

    tags[1].tagId = 0x80000001;
    tags[1].tagName = "aiEnhancementLevel";
    tags[1].tagType = ::android::hardware::camera::common::V1_0::CameraMetadataType::INT32;

    section.tags = tags;

    mVendorTagSections.resize(1);
    mVendorTagSections[0] = section;

    mInitialized = true;
    ALOGI("ExampleCameraProvider initialized with %zu cameras", mCameraDevices.size());
    return true;
}

void ExampleCameraProvider::discoverCameras() {
    ALOGI("Discovering cameras...");

    // In a real implementation, this would:
    // 1. Query the kernel for available camera devices
    // 2. Read device tree or config files
    // 3. Initialize hardware interfaces
    // Here we simulate 2 cameras (back and front)

    for (int i = 0; i < kNumCameras; i++) {
        CameraDeviceInfo info;
        info.cameraId = std::to_string(i);
        info.status = CameraDeviceStatus::PRESENT;
        info.hasTorch = (i == 0);  // Only back camera has flash
        info.torchStatus = TorchModeStatus::AVAILABLE_OFF;

        mCameraDevices[info.cameraId] = info;
        ALOGI("Discovered camera: %s (hasTorch=%d)", info.cameraId.c_str(), info.hasTorch);
    }
}

// ============================================================================
// ICameraProvider Interface Implementation
// ============================================================================

Return<Status> ExampleCameraProvider::setCallback(
    const sp<ICameraProviderCallback>& callback) {
    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("setCallback called");

    if (callback == nullptr) {
        ALOGW("Received null callback");
        return Status::ILLEGAL_ARGUMENT;
    }

    mCallback = callback;

    // Notify current camera status to the new callback
    for (const auto& pair : mCameraDevices) {
        const CameraDeviceInfo& info = pair.second;
        std::string deviceName = buildDeviceName(info.cameraId);

        // Report camera device status
        mCallback->cameraDeviceStatusChange(
            hidl_string(deviceName),
            info.status);

        // Report torch status if applicable
        if (info.hasTorch) {
            mCallback->torchModeStatusChange(
                hidl_string(deviceName),
                info.torchStatus);
        }
    }

    return Status::OK;
}

Return<void> ExampleCameraProvider::getVendorTags(getVendorTags_cb _hidl_cb) {
    ALOGI("getVendorTags called");
    _hidl_cb(Status::OK, mVendorTagSections);
    return Void();
}

Return<void> ExampleCameraProvider::getCameraIdList(getCameraIdList_cb _hidl_cb) {
    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("getCameraIdList called");

    hidl_vec<hidl_string> cameraIds(mCameraDevices.size());

    size_t i = 0;
    for (const auto& pair : mCameraDevices) {
        cameraIds[i++] = buildDeviceName(pair.first);
    }

    _hidl_cb(Status::OK, cameraIds);
    return Void();
}

Return<bool> ExampleCameraProvider::isSetTorchModeSupported() {
    // We support torch mode control
    return true;
}

Return<void> ExampleCameraProvider::getCameraDeviceInterface_V3_x(
    const hidl_string& cameraDeviceName,
    getCameraDeviceInterface_V3_x_cb _hidl_cb) {

    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("getCameraDeviceInterface_V3_x called for: %s", cameraDeviceName.c_str());

    // Parse camera ID from device name
    std::string cameraId = parseCameraId(cameraDeviceName);

    if (cameraId.empty()) {
        ALOGE("Failed to parse camera ID from: %s", cameraDeviceName.c_str());
        _hidl_cb(Status::ILLEGAL_ARGUMENT, nullptr);
        return Void();
    }

    // Check if camera exists
    auto it = mCameraDevices.find(cameraId);
    if (it == mCameraDevices.end()) {
        ALOGE("Camera not found: %s", cameraId.c_str());
        _hidl_cb(Status::ILLEGAL_ARGUMENT, nullptr);
        return Void();
    }

    // Check camera status
    if (it->second.status != CameraDeviceStatus::PRESENT) {
        ALOGE("Camera not available: %s (status=%d)",
              cameraId.c_str(), static_cast<int>(it->second.status));
        _hidl_cb(Status::CAMERA_DISCONNECTED, nullptr);
        return Void();
    }

    // Create camera device instance
    // Note: In production, you might cache these or use a factory
    sp<device::V3_5::implementation::ExampleCameraDevice> device =
        new device::V3_5::implementation::ExampleCameraDevice(cameraId);

    if (device == nullptr) {
        ALOGE("Failed to create camera device for: %s", cameraId.c_str());
        _hidl_cb(Status::INTERNAL_ERROR, nullptr);
        return Void();
    }

    ALOGI("Created camera device for: %s", cameraId.c_str());
    _hidl_cb(Status::OK, device);
    return Void();
}

Return<Status> ExampleCameraProvider::notifyDeviceStateChange(
    ::android::hardware::hidl_bitfield<
        ::android::hardware::camera::provider::V2_5::DeviceState> newState) {

    std::lock_guard<std::mutex> lock(mMutex);

    ALOGI("notifyDeviceStateChange: state=0x%lx", static_cast<unsigned long>(newState));

    mDeviceState = newState;

    // Handle device state changes
    // Examples:
    // - NORMAL: Standard device operation
    // - BACK_COVERED: Back camera might be obstructed
    // - FRONT_COVERED: Front camera might be obstructed
    // - FOLDED: Device is folded (foldables)

    // In a real implementation, you might:
    // 1. Adjust camera availability based on state
    // 2. Modify camera behavior (e.g., power savings)
    // 3. Notify hardware of state changes

    return Status::OK;
}

// ============================================================================
// ICameraProvider 2.6 Methods
// ============================================================================

Return<void> ExampleCameraProvider::getConcurrentStreamingCameraIds(
    getConcurrentStreamingCameraIds_cb _hidl_cb) {

    ALOGI("getConcurrentStreamingCameraIds called");

    // Define which cameras can stream concurrently
    // For this example, we allow both cameras to stream together
    hidl_vec<hidl_vec<hidl_string>> combinations(1);

    // Combination 0: Both cameras can stream simultaneously
    if (mCameraDevices.size() >= 2) {
        combinations[0].resize(2);
        combinations[0][0] = buildDeviceName("0");
        combinations[0][1] = buildDeviceName("1");
    }

    _hidl_cb(Status::OK, combinations);
    return Void();
}

Return<void> ExampleCameraProvider::isConcurrentStreamCombinationSupported(
    const hidl_vec<::android::hardware::camera::provider::V2_6::
                       CameraIdAndStreamCombination>& configs,
    isConcurrentStreamCombinationSupported_cb _hidl_cb) {

    ALOGI("isConcurrentStreamCombinationSupported called with %zu configs",
          configs.size());

    // Check if the requested combination is supported
    // For simplicity, we support up to 2 concurrent cameras
    bool supported = (configs.size() <= 2);

    // In production, you would validate:
    // 1. Memory bandwidth constraints
    // 2. ISP pipeline limitations
    // 3. Power constraints
    // 4. Specific stream configurations

    _hidl_cb(Status::OK, supported);
    return Void();
}

// ============================================================================
// ICameraProvider 2.7 Methods
// ============================================================================

Return<void> ExampleCameraProvider::isConcurrentStreamCombinationSupported_2_7(
    const hidl_vec<::android::hardware::camera::provider::V2_7::
                       CameraIdAndStreamCombination>& configs,
    isConcurrentStreamCombinationSupported_2_7_cb _hidl_cb) {

    ALOGI("isConcurrentStreamCombinationSupported_2_7 called with %zu configs",
          configs.size());

    bool supported = (configs.size() <= 2);
    _hidl_cb(Status::OK, supported);
    return Void();
}

// ============================================================================
// Helper Methods
// ============================================================================

std::string ExampleCameraProvider::parseCameraId(const std::string& deviceName) const {
    // Expected format: "device@<version>/<type>/<id>"
    // Example: "device@3.5/internal/0"

    std::regex pattern("device@[0-9.]+/[a-z]+/([0-9]+)");
    std::smatch match;

    if (std::regex_search(deviceName, match, pattern) && match.size() > 1) {
        return match[1].str();
    }

    // Fallback: Try simple ID parsing
    size_t lastSlash = deviceName.find_last_of('/');
    if (lastSlash != std::string::npos && lastSlash + 1 < deviceName.size()) {
        return deviceName.substr(lastSlash + 1);
    }

    ALOGE("Failed to parse camera ID from device name: %s", deviceName.c_str());
    return "";
}

std::string ExampleCameraProvider::buildDeviceName(const std::string& cameraId) const {
    // Build device name: "device@<version>/<type>/<id>"
    return std::string("device@") + kDeviceVersion + "/" + kDeviceType + "/" + cameraId;
}

void ExampleCameraProvider::notifyCameraStatusChange(
    const std::string& cameraId,
    CameraDeviceStatus newStatus) {

    std::lock_guard<std::mutex> lock(mMutex);

    auto it = mCameraDevices.find(cameraId);
    if (it == mCameraDevices.end()) {
        ALOGE("notifyCameraStatusChange: Unknown camera %s", cameraId.c_str());
        return;
    }

    it->second.status = newStatus;

    if (mCallback != nullptr) {
        std::string deviceName = buildDeviceName(cameraId);
        mCallback->cameraDeviceStatusChange(hidl_string(deviceName), newStatus);
    }
}

void ExampleCameraProvider::notifyTorchStatusChange(
    const std::string& cameraId,
    TorchModeStatus newStatus) {

    std::lock_guard<std::mutex> lock(mMutex);

    auto it = mCameraDevices.find(cameraId);
    if (it == mCameraDevices.end()) {
        ALOGE("notifyTorchStatusChange: Unknown camera %s", cameraId.c_str());
        return;
    }

    if (!it->second.hasTorch) {
        ALOGW("notifyTorchStatusChange: Camera %s has no torch", cameraId.c_str());
        return;
    }

    it->second.torchStatus = newStatus;

    if (mCallback != nullptr) {
        std::string deviceName = buildDeviceName(cameraId);
        mCallback->torchModeStatusChange(hidl_string(deviceName), newStatus);
    }
}

// ============================================================================
// HIDL Service Registration
// ============================================================================

extern "C" ICameraProvider* HIDL_FETCH_ICameraProvider(const char* name) {
    ALOGI("HIDL_FETCH_ICameraProvider: %s", name);

    // Create and initialize provider
    ExampleCameraProvider* provider = new ExampleCameraProvider();

    if (!provider->initialize()) {
        ALOGE("Failed to initialize camera provider");
        delete provider;
        return nullptr;
    }

    return provider;
}

}  // namespace implementation
}  // namespace V2_7
}  // namespace provider
}  // namespace camera
}  // namespace hardware
}  // namespace android

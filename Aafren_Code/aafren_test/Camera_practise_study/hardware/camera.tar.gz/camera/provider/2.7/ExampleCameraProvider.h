/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Example Camera HAL Provider Implementation
 *
 * This file demonstrates the implementation of ICameraProvider interface,
 * which is the entry point for the Camera HAL. The provider is responsible
 * for:
 * - Enumerating available camera devices
 * - Creating camera device instances
 * - Notifying framework of camera availability changes
 */

#pragma once

#include <android/hardware/camera/provider/2.7/ICameraProvider.h>
#include <android/hardware/camera/provider/2.7/ICameraProviderCallback.h>
#include <hidl/MQDescriptor.h>
#include <hidl/Status.h>

#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace android {
namespace hardware {
namespace camera {
namespace provider {
namespace V2_7 {
namespace implementation {

using ::android::sp;
using ::android::hardware::hidl_string;
using ::android::hardware::hidl_vec;
using ::android::hardware::Return;
using ::android::hardware::Void;
using ::android::hardware::camera::common::V1_0::CameraDeviceStatus;
using ::android::hardware::camera::common::V1_0::Status;
using ::android::hardware::camera::common::V1_0::TorchModeStatus;
using ::android::hardware::camera::common::V1_0::VendorTagSection;
using ::android::hardware::camera::device::V3_2::ICameraDevice;

/**
 * Camera Device Information
 *
 * Holds information about each camera device managed by the provider.
 */
struct CameraDeviceInfo {
    std::string cameraId;           // Unique camera identifier (e.g., "0", "1")
    std::string resourceCost;       // Resource cost for simultaneous usage
    CameraDeviceStatus status;      // Current device status
    bool hasTorch;                  // Whether device has flash unit
    TorchModeStatus torchStatus;    // Current torch status
};

/**
 * ExampleCameraProvider
 *
 * Main implementation of the ICameraProvider HAL interface.
 *
 * Key Responsibilities:
 * 1. Device Enumeration: Discover and list available cameras
 * 2. Device Creation: Create camera device instances on demand
 * 3. Status Callbacks: Notify framework of camera/torch status changes
 * 4. Vendor Tags: Provide custom metadata tags for vendor-specific features
 *
 * Architecture:
 * ┌─────────────────────────────────────────────────────────┐
 * │                    Camera Framework                      │
 * └────────────────────────┬────────────────────────────────┘
 *                          │ HIDL IPC
 * ┌────────────────────────▼────────────────────────────────┐
 * │               ExampleCameraProvider                      │
 * │  ┌───────────────┐  ┌───────────────┐  ┌──────────────┐ │
 * │  │ Device List   │  │ Vendor Tags   │  │  Callbacks   │ │
 * │  └───────────────┘  └───────────────┘  └──────────────┘ │
 * └────────────────────────┬────────────────────────────────┘
 *                          │
 * ┌────────────────────────▼────────────────────────────────┐
 * │              ExampleCameraDevice (x N)                   │
 * └─────────────────────────────────────────────────────────┘
 */
class ExampleCameraProvider : public ICameraProvider {
public:
    ExampleCameraProvider();
    virtual ~ExampleCameraProvider();

    // ========================================================================
    // ICameraProvider Interface Methods (HIDL)
    // ========================================================================

    /**
     * setCallback - Register provider callback for status notifications
     *
     * @param callback: Callback interface for camera/torch status changes
     * @return Status indicating success or failure
     *
     * The framework calls this immediately after getting the provider.
     * The HAL must store this callback and use it to notify:
     * - Camera device availability changes (hot-plug events)
     * - Torch mode availability changes
     */
    Return<Status> setCallback(
        const sp<ICameraProviderCallback>& callback) override;

    /**
     * getVendorTags - Get vendor-specific metadata tags
     *
     * @param _hidl_cb: Callback to return vendor tag sections
     * @return Void (result via callback)
     *
     * Vendor tags allow OEMs to define custom metadata keys for
     * proprietary camera features. Each section groups related tags.
     */
    Return<void> getVendorTags(getVendorTags_cb _hidl_cb) override;

    /**
     * getCameraIdList - Get list of camera device IDs
     *
     * @param _hidl_cb: Callback to return camera IDs
     * @return Void (result via callback)
     *
     * Returns IDs of all cameras that were available at provider
     * initialization. Does not include cameras discovered later
     * (those are reported via callback).
     */
    Return<void> getCameraIdList(getCameraIdList_cb _hidl_cb) override;

    /**
     * isSetTorchModeSupported - Check if torch mode control is supported
     *
     * @return Boolean indicating torch mode support
     *
     * If true, the framework may call setTorchMode() to control flash.
     */
    Return<bool> isSetTorchModeSupported() override;

    /**
     * getCameraDeviceInterface_V3_x - Create camera device instance
     *
     * @param cameraDeviceName: Full device name (e.g., "device@3.5/internal/0")
     * @param _hidl_cb: Callback to return device interface
     * @return Void (result via callback)
     *
     * Creates and returns an ICameraDevice interface for the specified camera.
     * The device is not opened yet - that happens when open() is called on it.
     */
    Return<void> getCameraDeviceInterface_V3_x(
        const hidl_string& cameraDeviceName,
        getCameraDeviceInterface_V3_x_cb _hidl_cb) override;

    /**
     * notifyDeviceStateChange - Handle device state changes
     *
     * @param newState: Bitmask of device states
     * @return Status indicating success or failure
     *
     * Called when device state changes (e.g., folded/unfolded, docked).
     * HAL may adjust camera behavior or availability based on state.
     */
    Return<Status> notifyDeviceStateChange(
        ::android::hardware::hidl_bitfield<
            ::android::hardware::camera::provider::V2_5::DeviceState> newState)
        override;

    // ========================================================================
    // ICameraProvider 2.6 Methods
    // ========================================================================

    /**
     * getConcurrentStreamingCameraIds - Get concurrent streaming capabilities
     *
     * @param _hidl_cb: Callback to return concurrent camera combinations
     * @return Void (result via callback)
     *
     * Returns combinations of cameras that can stream simultaneously.
     * Essential for multi-camera use cases (e.g., picture-in-picture).
     */
    Return<void> getConcurrentStreamingCameraIds(
        getConcurrentStreamingCameraIds_cb _hidl_cb) override;

    /**
     * isConcurrentStreamCombinationSupported - Check stream combination support
     *
     * @param configs: Stream configurations for multiple cameras
     * @param _hidl_cb: Callback to return support status
     * @return Void (result via callback)
     */
    Return<void> isConcurrentStreamCombinationSupported(
        const hidl_vec<::android::hardware::camera::provider::V2_6::
                           CameraIdAndStreamCombination>& configs,
        isConcurrentStreamCombinationSupported_cb _hidl_cb) override;

    // ========================================================================
    // ICameraProvider 2.7 Methods
    // ========================================================================

    /**
     * isConcurrentStreamCombinationSupported_2_7 - Enhanced concurrent support
     *
     * Extended version with additional stream configuration options.
     */
    Return<void> isConcurrentStreamCombinationSupported_2_7(
        const hidl_vec<::android::hardware::camera::provider::V2_7::
                           CameraIdAndStreamCombination>& configs,
        isConcurrentStreamCombinationSupported_2_7_cb _hidl_cb) override;

    // ========================================================================
    // Public Helper Methods
    // ========================================================================

    /**
     * Initialize the provider
     *
     * Called during service startup to discover cameras and set up resources.
     * @return true if initialization succeeded
     */
    bool initialize();

    /**
     * Get the provider name for service registration
     */
    static const char* getProviderName() {
        return "meta/example";
    }

private:
    // ========================================================================
    // Private Helper Methods
    // ========================================================================

    /**
     * Discover and enumerate all available camera devices
     */
    void discoverCameras();

    /**
     * Parse camera device name to extract camera ID
     *
     * @param deviceName: Full device name (e.g., "device@3.5/internal/0")
     * @return Extracted camera ID or empty string on failure
     */
    std::string parseCameraId(const std::string& deviceName) const;

    /**
     * Build full device name from camera ID
     *
     * @param cameraId: Simple camera ID (e.g., "0")
     * @return Full device name for HAL communication
     */
    std::string buildDeviceName(const std::string& cameraId) const;

    /**
     * Notify framework of camera status change
     */
    void notifyCameraStatusChange(const std::string& cameraId,
                                   CameraDeviceStatus newStatus);

    /**
     * Notify framework of torch status change
     */
    void notifyTorchStatusChange(const std::string& cameraId,
                                  TorchModeStatus newStatus);

    // ========================================================================
    // Member Variables
    // ========================================================================

    // Mutex for thread-safe access to provider state
    mutable std::mutex mMutex;

    // Map of camera ID to device info
    std::map<std::string, CameraDeviceInfo> mCameraDevices;

    // Provider callback for status notifications
    sp<ICameraProviderCallback> mCallback;

    // Vendor tag sections for custom metadata
    hidl_vec<VendorTagSection> mVendorTagSections;

    // Provider initialization status
    bool mInitialized;

    // Device state flags
    uint64_t mDeviceState;
};

// Service registration helper
extern "C" ICameraProvider* HIDL_FETCH_ICameraProvider(const char* name);

}  // namespace implementation
}  // namespace V2_7
}  // namespace provider
}  // namespace camera
}  // namespace hardware
}  // namespace android

/*
 * Copyright (C) 2024 Meta Platforms, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Example Camera HAL Service Main Entry Point
 *
 * This file is the entry point for the Camera HAL service.
 * It registers the Camera Provider with the Hardware Service Manager,
 * allowing the Camera Framework to discover and use our HAL.
 */

#define LOG_TAG "ExampleCameraHAL"

#include <android-base/logging.h>
#include <hidl/HidlTransportSupport.h>
#include <utils/StrongPointer.h>

#include "provider/2.7/ExampleCameraProvider.h"

using ::android::sp;
using ::android::hardware::configureRpcThreadpool;
using ::android::hardware::joinRpcThreadpool;
using ::android::hardware::camera::provider::V2_7::ICameraProvider;
using ::android::hardware::camera::provider::V2_7::implementation::ExampleCameraProvider;

/**
 * Main entry point for the Camera HAL service
 *
 * Startup Flow:
 * ┌───────────────────────────────────────────────────────────────┐
 * │                    Camera HAL Service Startup                 │
 * ├───────────────────────────────────────────────────────────────┤
 * │                                                                │
 * │   1. Configure RPC Thread Pool                                │
 * │      └─ Set max threads for HIDL communication               │
 * │                                                                │
 * │   2. Create Camera Provider                                   │
 * │      └─ Initialize hardware, enumerate cameras               │
 * │                                                                │
 * │   3. Register as HIDL Service                                 │
 * │      └─ Make provider discoverable by Camera Framework       │
 * │                                                                │
 * │   4. Join RPC Thread Pool                                     │
 * │      └─ Start handling incoming requests (blocks)            │
 * │                                                                │
 * └───────────────────────────────────────────────────────────────┘
 */
int main(int /* argc */, char* /* argv */[]) {
    ALOGI("====================================");
    ALOGI("  Example Camera HAL Service v2.7  ");
    ALOGI("====================================");

    // Configure RPC thread pool
    // - maxThreads: Number of threads to handle HIDL requests
    // - callerWillJoin: true means this thread will join the pool
    const int kMaxThreads = 4;
    configureRpcThreadpool(kMaxThreads, true /* callerWillJoin */);

    ALOGI("RPC thread pool configured with %d threads", kMaxThreads);

    // Create and initialize the camera provider
    sp<ICameraProvider> provider = new ExampleCameraProvider();

    // Cast to implementation to call initialize()
    ExampleCameraProvider* providerImpl =
        static_cast<ExampleCameraProvider*>(provider.get());

    if (!providerImpl->initialize()) {
        ALOGE("Failed to initialize camera provider");
        return EXIT_FAILURE;
    }

    ALOGI("Camera provider initialized successfully");

    // Register as a HIDL service
    // The provider name must match what's expected by the Camera Framework
    // Format: "internal/<number>" or "external/<number>"
    const std::string kProviderName = "meta/example/0";

    android::status_t status = provider->registerAsService(kProviderName);

    if (status != android::OK) {
        ALOGE("Failed to register camera provider service: %s (%d)",
              strerror(-status), status);
        return EXIT_FAILURE;
    }

    ALOGI("Camera provider registered as: %s", kProviderName.c_str());
    ALOGI("Camera HAL service ready, waiting for requests...");

    // Join the RPC thread pool
    // This call blocks and handles incoming HIDL requests
    joinRpcThreadpool();

    // If we get here, something went wrong
    ALOGE("Camera HAL service exiting unexpectedly");
    return EXIT_FAILURE;
}
